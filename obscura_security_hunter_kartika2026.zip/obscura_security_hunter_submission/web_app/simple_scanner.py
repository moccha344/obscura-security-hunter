#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple Scanner Wrapper for Web App
Avoids stdout/stderr conflicts
"""

import requests
import json
import re
from datetime import datetime
from urllib.parse import urlparse, urljoin
import warnings

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

class SimpleScanner:
    """Simplified scanner that doesn't modify stdout/stderr"""
    
    def __init__(self, target_url, scan_id=None, callback=None):
        self.target_url = target_url.rstrip('/')
        self.domain = urlparse(target_url).netloc
        self.scan_id = scan_id
        self.callback = callback
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.findings = []
    
    def run_full_scan(self):
        """Run comprehensive security scan"""
        results = {
            'target_url': self.target_url,
            'scan_time': datetime.now().isoformat(),
            'findings': [],
            'summary': {
                'total_tests': 8,
                'critical': 0,
                'high': 0,
                'medium': 0,
                'low': 0
            }
        }
        
        # Phase 1: Basic Reconnaissance
        phase1 = self._phase_reconnaissance()
        if phase1:
            results['findings'].append(phase1)
        
        # Phase 2: API Testing
        phase2 = self._phase_api_testing()
        if phase2:
            results['findings'].append(phase2)
            self._count_severities(phase2, results['summary'])
        
        # Phase 3: Cloud Misconfiguration
        phase3 = self._phase_cloud_testing()
        if phase3:
            results['findings'].append(phase3)
            self._count_severities(phase3, results['summary'])
        
        # Phase 4: Business Logic
        phase4 = self._phase_business_logic()
        if phase4:
            results['findings'].append(phase4)
            self._count_severities(phase4, results['summary'])
        
        # Phase 5: Authentication Testing
        phase5 = self._phase_auth_testing()
        if phase5:
            results['findings'].append(phase5)
            self._count_severities(phase5, results['summary'])
        
        # Phase 6: Backend Vulnerabilities
        phase6 = self._phase_backend_testing()
        if phase6:
            results['findings'].append(phase6)
            self._count_severities(phase6, results['summary'])
        
        # Phase 7: Security Headers
        phase7 = self._phase_security_headers()
        if phase7:
            results['findings'].append(phase7)
            self._count_severities(phase7, results['summary'])
        
        # Phase 8: SSL/TLS Testing
        phase8 = self._phase_ssl_testing()
        if phase8:
            results['findings'].append(phase8)
            self._count_severities(phase8, results['summary'])
        
        return results
    
    def _count_severities(self, phase_data, summary):
        """Count vulnerabilities by severity"""
        if 'vulnerabilities' in phase_data:
            for vuln in phase_data['vulnerabilities']:
                severity = vuln.get('severity', 'LOW')
                if severity == 'CRITICAL':
                    summary['critical'] += 1
                elif severity == 'HIGH':
                    summary['high'] += 1
                elif severity == 'MEDIUM':
                    summary['medium'] += 1
                else:
                    summary['low'] += 1
    
    def _phase_reconnaissance(self):
        """Phase 1: Basic reconnaissance"""
        result = {
            'phase': 'Reconnaissance',
            'status': 'completed',
            'info': {},
            'vulnerabilities': []
        }
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            headers = response.headers
            
            # Technology stack detection
            technologies = []
            detected_versions = {}
            
            if 'Server' in headers:
                server = headers['Server']
                technologies.append(f"Web Server: {server}")
                detected_versions['server'] = server
                
            if 'X-Powered-By' in headers:
                framework = headers['X-Powered-By']
                technologies.append(f"Framework: {framework}")
                detected_versions['framework'] = framework
            
            # Detect CMS/Framework from response
            content = response.text.lower()
            cms_signatures = {
                'wordpress': ('wp-content' in content or 'wp-includes' in content),
                'joomla': 'joomla' in content,
                'drupal': 'drupal' in content,
                'laravel': 'laravel' in content,
                'django': 'csrfmiddlewaretoken' in content,
                'react': 'react' in content,
                'vue': ('vue' in content or '__vue__' in content),
                'angular': 'ng-' in content,
                'jquery': 'jquery' in content
            }
            
            detected_cms = []
            for cms, found in cms_signatures.items():
                if found:
                    detected_cms.append(cms.title())
                    detected_versions[cms] = 'detected'
            
            if detected_cms:
                technologies.append(f"Detected Technology: {', '.join(detected_cms)}")
            
            # CVE Detection based on technologies
            cve_findings = self._check_known_cves(detected_versions, content, headers)
            if cve_findings:
                result['vulnerabilities'].extend(cve_findings)
            
            result['info'] = {
                'status_code': response.status_code,
                'response_time': f'{response.elapsed.total_seconds():.2f} seconds',
                'content_length': f'{len(response.content)} bytes',
                'content_type': headers.get('Content-Type', 'Unknown'),
                'technologies': technologies if technologies else ['Unable to detect specific technologies'],
                'https_enabled': self.target_url.startswith('https://'),
                'redirects': f'{len(response.history)} redirect(s)' if response.history else 'No redirects'
            }
        except Exception as e:
            result['info'] = {'error': f'Failed to connect: {str(e)}'}
        
        return result
    
    def _check_known_cves(self, detected_versions, content, headers):
        """Check for known CVEs based on detected technologies"""
        cves = []
        
        # Apache version detection & CVE check
        server = detected_versions.get('server', '').lower()
        if 'apache' in server:
            # Extract version
            import re
            version_match = re.search(r'apache[/\s]?([\d.]+)', server)
            if version_match:
                version = version_match.group(1)
                # Check for known vulnerable versions
                if version.startswith('2.4.') and int(version.split('.')[2]) < 51:
                    cves.append({
                        'type': 'Known CVE: Apache HTTP Server Path Traversal',
                        'severity': 'HIGH',
                        'cve_id': 'CVE-2021-41773',
                        'evidence': f'Apache version {version} vulnerable to path traversal. Upgrade to 2.4.51 or higher.',
                        'affected_component': f'Apache/{version}'
                    })
        
        # WordPress version & CVE check
        if 'wordpress' in detected_versions:
            # Try to detect WP version
            wp_version_patterns = [
                r'<meta name="generator" content="WordPress ([\d.]+)"',
                r'wp-includes/js/[^"]+\?ver=([\d.]+)',
                r'/wp-content/themes/[^/]+/style\.css\?ver=([\d.]+)'
            ]
            
            for pattern in wp_version_patterns:
                match = re.search(pattern, content)
                if match:
                    wp_version = match.group(1)
                    cves.append({
                        'type': 'CMS Version Disclosure: WordPress',
                        'severity': 'MEDIUM',
                        'evidence': f'WordPress version {wp_version} terdeteksi. Pastikan versi terbaru untuk menghindari CVE.',
                        'affected_component': f'WordPress {wp_version}'
                    })
                    break
        
        # PHP version detection
        if 'X-Powered-By' in headers:
            php_header = headers['X-Powered-By']
            if 'php' in php_header.lower():
                php_match = re.search(r'php[/\s]?([\d.]+)', php_header, re.I)
                if php_match:
                    php_version = php_match.group(1)
                    major_version = php_version.split('.')[0]
                    
                    # Check for EOL PHP versions
                    if major_version in ['5', '7.0', '7.1', '7.2', '7.3']:
                        cves.append({
                            'type': 'End-of-Life Software: PHP Version',
                            'severity': 'HIGH',
                            'evidence': f'PHP {php_version} sudah End-of-Life dan tidak menerima security updates. Sangat rentan terhadap CVE terbaru.',
                            'affected_component': f'PHP/{php_version}',
                            'recommendation': 'Upgrade ke PHP 8.0 atau lebih baru'
                        })
        
        # jQuery version & known CVEs
        if 'jquery' in detected_versions or 'jquery' in content:
            jquery_match = re.search(r'jquery[/-]([\d.]+)', content)
            if jquery_match:
                jquery_ver = jquery_match.group(1)
                if jquery_ver.startswith('1.') or jquery_ver.startswith('2.'):
                    cves.append({
                        'type': 'Known CVE: jQuery XSS Vulnerability',
                        'severity': 'MEDIUM',
                        'cve_id': 'CVE-2020-11022',
                        'evidence': f'jQuery version {jquery_ver} vulnerable to XSS via htmlPrefilter. Upgrade to 3.5.0 or higher.',
                        'affected_component': f'jQuery {jquery_ver}'
                    })
        
        # Check for exposed version in HTML comments
        comment_versions = re.findall(r'<!-- [^>]*version[:\s]*([\d.]+)', content, re.I)
        if comment_versions:
            cves.append({
                'type': 'Information Disclosure: Version in HTML Comments',
                'severity': 'LOW',
                'evidence': f'Version information found in HTML comments: {", ".join(comment_versions)}. Ini memudahkan attacker untuk target CVE spesifik.',
                'affected_component': 'HTML Comments'
            })
        
        return cves
    
    def _phase_api_testing(self):
        """Phase 2: API security testing"""
        result = {
            'phase': 'API Testing',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        # Test common API endpoints with detailed analysis
        api_paths = ['/api/', '/api/v1/', '/api/users', '/api/admin', '/graphql', '/api/auth']
        
        for path in api_paths:
            url = urljoin(self.target_url, path)
            try:
                response = self.session.get(url, timeout=5)
                
                if response.status_code == 200:
                    # Analyze response content
                    content_type = response.headers.get('Content-Type', '')
                    content = response.text.lower()
                    
                    # Check for sensitive data exposure
                    if 'application/json' in content_type:
                        severity = 'HIGH'
                        vuln_type = 'API Endpoint Exposing Structured Data'
                        evidence = f'Returns JSON data ({len(response.content)} bytes). May expose sensitive information.'
                        
                        # Check for common sensitive patterns
                        if any(word in content for word in ['password', 'token', 'secret', 'key', 'admin']):
                            severity = 'CRITICAL'
                            evidence += ' ALERT: Response may contain sensitive keywords!'
                    else:
                        severity = 'MEDIUM'
                        vuln_type = 'Unauthenticated API Endpoint Access'
                        evidence = f'Endpoint accessible without authentication (Status: {response.status_code}, Size: {len(response.content)} bytes)'
                    
                    result['vulnerabilities'].append({
                        'type': vuln_type,
                        'severity': severity,
                        'endpoint': path,
                        'evidence': evidence
                    })
                    
                elif response.status_code == 401:
                    # Good - requires authentication
                    pass
                elif response.status_code == 403:
                    result['vulnerabilities'].append({
                        'type': 'API Endpoint Exists But Forbidden',
                        'severity': 'LOW',
                        'endpoint': path,
                        'evidence': f'Endpoint exists but returns 403. May be accessible with proper authorization.'
                    })
            except Exception as e:
                pass
        
        # Test for GraphQL introspection
        graphql_url = urljoin(self.target_url, '/graphql')
        try:
            introspection_query = {'query': '{ __schema { types { name } } }'}
            response = self.session.post(graphql_url, json=introspection_query, timeout=5)
            if response.status_code == 200 and '__schema' in response.text:
                result['vulnerabilities'].append({
                    'type': 'GraphQL Introspection Enabled',
                    'severity': 'HIGH',
                    'endpoint': '/graphql',
                    'evidence': 'GraphQL introspection is enabled, allowing attackers to discover entire API schema'
                })
        except:
            pass
        
        return result
    
    def _phase_cloud_testing(self):
        """Phase 3: Cloud misconfiguration testing"""
        result = {
            'phase': 'Cloud Security',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        # Test for cloud metadata endpoints
        metadata_urls = [
            'http://169.254.169.254/latest/meta-data/',  # AWS
            'http://metadata.google.internal/computeMetadata/v1/',  # GCP
        ]
        
        for metadata_url in metadata_urls:
            try:
                response = self.session.get(metadata_url, timeout=3)
                if response.status_code == 200:
                    result['vulnerabilities'].append({
                        'type': 'Cloud Metadata Access',
                        'severity': 'CRITICAL',
                        'endpoint': metadata_url,
                        'evidence': 'Metadata endpoint accessible'
                    })
            except:
                pass
        
        return result
    
    def _phase_business_logic(self):
        """Phase 4: Business logic testing"""
        result = {
            'phase': 'Business Logic',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        # Test for common business logic issues
        test_endpoints = ['/checkout', '/payment', '/cart', '/order']
        
        for endpoint in test_endpoints:
            url = urljoin(self.target_url, endpoint)
            try:
                response = self.session.get(url, timeout=5)
                if response.status_code in [200, 302]:
                    result['vulnerabilities'].append({
                        'type': 'Business Logic Endpoint Found',
                        'severity': 'LOW',
                        'endpoint': endpoint,
                        'evidence': f'Endpoint accessible: {response.status_code}'
                    })
            except:
                pass
        
        return result
    
    def _phase_auth_testing(self):
        """Phase 5: Authentication testing"""
        result = {
            'phase': 'Authentication',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        # Test authentication endpoints
        auth_paths = ['/login', '/admin', '/dashboard', '/api/auth']
        
        for path in auth_paths:
            url = urljoin(self.target_url, path)
            try:
                response = self.session.get(url, timeout=5)
                if response.status_code == 200:
                    result['vulnerabilities'].append({
                        'type': 'Authentication Endpoint Found',
                        'severity': 'LOW',
                        'endpoint': path,
                        'evidence': f'Endpoint exists: {response.status_code}'
                    })
            except:
                pass
        
        return result
    
    def _phase_backend_testing(self):
        """Phase 6: Backend vulnerability testing"""
        result = {
            'phase': 'Backend Security',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        # Test for sensitive file exposure with detailed checks
        sensitive_files = {
            '/.git/config': 'Git Repository Configuration',
            '/.git/HEAD': 'Git HEAD Reference',
            '/.env': 'Environment Configuration File',
            '/config.php': 'PHP Configuration File',
            '/wp-config.php': 'WordPress Configuration',
            '/web.config': 'IIS Configuration',
            '/.htaccess': 'Apache Configuration',
            '/composer.json': 'PHP Dependency Manifest',
            '/package.json': 'Node.js Dependency Manifest',
            '/robots.txt': 'Robots.txt File'
        }
        
        for file_path, description in sensitive_files.items():
            url = urljoin(self.target_url, file_path)
            try:
                response = self.session.get(url, timeout=5)
                
                if response.status_code == 200 and len(response.content) > 0:
                    content = response.text
                    severity = 'HIGH'
                    evidence_detail = f'File size: {len(response.content)} bytes. '
                    
                    # Analyze content for severity
                    if file_path == '/.git/config':
                        severity = 'CRITICAL'
                        if 'url' in content.lower():
                            evidence_detail += 'CRITICAL: Git repository exposed! May contain source code and credentials.'
                    elif file_path == '/.env':
                        severity = 'CRITICAL'
                        if any(word in content.upper() for word in ['PASSWORD', 'SECRET', 'KEY', 'TOKEN', 'API']):
                            evidence_detail += 'CRITICAL: Environment file contains sensitive credentials!'
                        else:
                            evidence_detail += 'Environment configuration exposed.'
                    elif 'config' in file_path:
                        if any(word in content.lower() for word in ['password', 'db_pass', 'secret', 'key']):
                            severity = 'CRITICAL'
                            evidence_detail += 'Configuration file may contain database credentials or API keys!'
                        else:
                            evidence_detail += 'Configuration file accessible - may reveal system information.'
                    elif file_path == '/robots.txt':
                        severity = 'LOW'
                        evidence_detail += 'Robots.txt found - may reveal hidden directories. '
                        # Check for interesting disallows
                        if 'disallow' in content.lower():
                            disallowed = [line for line in content.split('\n') if 'disallow' in line.lower()]
                            evidence_detail += f'Found {len(disallowed)} disallowed paths that may be interesting.'
                    else:
                        evidence_detail += 'Sensitive file accessible.'
                    
                    result['vulnerabilities'].append({
                        'type': f'Sensitive File Exposure: {description}',
                        'severity': severity,
                        'file': file_path,
                        'evidence': evidence_detail
                    })
            except:
                pass
        
        return result
    
    def _phase_security_headers(self):
        """Phase 7: Security headers testing"""
        result = {
            'phase': 'Security Headers',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        try:
            response = self.session.get(self.target_url, timeout=10)
            headers = response.headers
            
            # Check for missing security headers with detailed impact
            security_headers = {
                'X-Frame-Options': {
                    'severity': 'MEDIUM',
                    'impact': 'Missing X-Frame-Options allows clickjacking attacks. Attacker can embed site in iframe.',
                    'recommendation': 'Set X-Frame-Options: DENY or SAMEORIGIN'
                },
                'X-Content-Type-Options': {
                    'severity': 'LOW',
                    'impact': 'Missing X-Content-Type-Options allows MIME-type sniffing attacks.',
                    'recommendation': 'Set X-Content-Type-Options: nosniff'
                },
                'Strict-Transport-Security': {
                    'severity': 'HIGH',
                    'impact': 'Missing HSTS header allows man-in-the-middle attacks via SSL stripping.',
                    'recommendation': 'Set Strict-Transport-Security: max-age=31536000; includeSubDomains'
                },
                'Content-Security-Policy': {
                    'severity': 'MEDIUM',
                    'impact': 'Missing CSP allows XSS attacks and unauthorized resource loading.',
                    'recommendation': 'Implement Content-Security-Policy with appropriate directives'
                },
                'X-XSS-Protection': {
                    'severity': 'LOW',
                    'impact': 'Missing X-XSS-Protection reduces XSS attack protection in older browsers.',
                    'recommendation': 'Set X-XSS-Protection: 1; mode=block'
                },
                'Referrer-Policy': {
                    'severity': 'LOW',
                    'impact': 'Missing Referrer-Policy may leak sensitive URL information to third parties.',
                    'recommendation': 'Set Referrer-Policy: strict-origin-when-cross-origin'
                }
            }
            
            for header, info in security_headers.items():
                if header not in headers:
                    result['vulnerabilities'].append({
                        'type': f'Missing Security Header: {header}',
                        'severity': info['severity'],
                        'header': header,
                        'evidence': f"Impact: {info['impact']} Recommendation: {info['recommendation']}"
                    })
                else:
                    # Header present - check if properly configured
                    value = headers[header]
                    if header == 'Strict-Transport-Security':
                        if 'max-age' not in value or int(value.split('max-age=')[1].split(';')[0]) < 31536000:
                            result['vulnerabilities'].append({
                                'type': 'Weak HSTS Configuration',
                                'severity': 'MEDIUM',
                                'header': header,
                                'evidence': f'HSTS present but weak: "{value}". Should be at least 1 year (31536000 seconds)'
                            })
            
            # Check for information disclosure headers
            disclosure_headers = ['Server', 'X-Powered-By', 'X-AspNet-Version', 'X-AspNetMvc-Version']
            for header in disclosure_headers:
                if header in headers:
                    result['vulnerabilities'].append({
                        'type': 'Information Disclosure via Headers',
                        'severity': 'LOW',
                        'header': header,
                        'evidence': f'Header "{header}: {headers[header]}" reveals technology stack information'
                    })
        except:
            pass
        
        return result
    
    def _phase_ssl_testing(self):
        """Phase 8: SSL/TLS testing"""
        result = {
            'phase': 'SSL/TLS Security',
            'status': 'completed',
            'vulnerabilities': []
        }
        
        if self.target_url.startswith('http://'):
            result['vulnerabilities'].append({
                'type': 'No HTTPS',
                'severity': 'HIGH',
                'evidence': 'Website not using HTTPS'
            })
        else:
            try:
                response = self.session.get(self.target_url, timeout=10)
                # Basic check - detailed SSL testing would require additional libraries
                result['vulnerabilities'].append({
                    'type': 'HTTPS Enabled',
                    'severity': 'INFO',
                    'evidence': 'Website using HTTPS'
                })
            except:
                pass
        
        return result
