@echo off
echo ========================================
echo Ultimate Security Hunter - Web App
echo ========================================
echo.
echo [*] Starting Flask server...
echo [*] Access at: http://localhost:5000
echo [*] Press Ctrl+C to stop
echo.
echo ========================================
echo.

python app.py

pause
