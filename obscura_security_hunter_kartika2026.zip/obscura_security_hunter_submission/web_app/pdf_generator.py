#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF Report Generator - Bahasa Indonesia
Generates professional security assessment reports
"""

from datetime import datetime
import json

def generate_html_report(scan_results, scan_id):
    """Generate HTML report in Indonesian"""
    
    target_url = scan_results.get('target_url', 'Unknown')
    scan_time = scan_results.get('scan_time', datetime.now().isoformat())
    findings = scan_results.get('findings', [])
    summary = scan_results.get('summary', {})
    
    # Count vulnerabilities by severity
    total_critical = summary.get('critical', 0)
    total_high = summary.get('high', 0)
    total_medium = summary.get('medium', 0)
    total_low = summary.get('low', 0)
    total_vulns = total_critical + total_high + total_medium + total_low
    
    html = f"""
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Laporan Keamanan - {target_url}</title>
        <style>
            @page {{
                size: A4;
                margin: 2cm;
            }}
            body {{
                font-family: 'Arial', sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 210mm;
                margin: 0 auto;
                padding: 20px;
            }}
            .header {{
                text-align: center;
                border-bottom: 3px solid #2563eb;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }}
            .header h1 {{
                color: #2563eb;
                font-size: 24px;
                margin: 10px 0;
            }}
            .header .subtitle {{
                color: #666;
                font-size: 14px;
            }}
            .info-box {{
                background: #f3f4f6;
                border-left: 4px solid #2563eb;
                padding: 15px;
                margin: 20px 0;
            }}
            .info-box h3 {{
                margin-top: 0;
                color: #2563eb;
            }}
            .summary-grid {{
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 15px;
                margin: 20px 0;
            }}
            .summary-card {{
                text-align: center;
                padding: 20px;
                border-radius: 8px;
                color: white;
            }}
            .summary-card.critical {{ background: #ef4444; }}
            .summary-card.high {{ background: #f59e0b; }}
            .summary-card.medium {{ background: #3b82f6; }}
            .summary-card.low {{ background: #10b981; }}
            .summary-card h2 {{
                font-size: 36px;
                margin: 10px 0;
            }}
            .summary-card p {{
                margin: 0;
                font-size: 14px;
            }}
            .finding {{
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 20px;
                margin: 20px 0;
                page-break-inside: avoid;
            }}
            .finding-header {{
                background: #2563eb;
                color: white;
                padding: 10px 15px;
                margin: -20px -20px 15px -20px;
                border-radius: 8px 8px 0 0;
                font-weight: bold;
            }}
            .vulnerability {{
                border-left: 4px solid #e5e7eb;
                padding: 15px;
                margin: 15px 0;
                background: #f9fafb;
            }}
            .vulnerability.critical {{ border-color: #ef4444; }}
            .vulnerability.high {{ border-color: #f59e0b; }}
            .vulnerability.medium {{ border-color: #3b82f6; }}
            .vulnerability.low {{ border-color: #10b981; }}
            .badge {{
                display: inline-block;
                padding: 4px 12px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: bold;
                color: white;
                margin-right: 10px;
            }}
            .badge.critical {{ background: #ef4444; }}
            .badge.high {{ background: #f59e0b; }}
            .badge.medium {{ background: #3b82f6; }}
            .badge.low {{ background: #10b981; }}
            .url-link {{
                color: #2563eb;
                word-break: break-all;
                font-family: monospace;
                font-size: 12px;
            }}
            .evidence {{
                background: #fff;
                border: 1px solid #e5e7eb;
                padding: 10px;
                margin-top: 10px;
                font-size: 13px;
                border-radius: 4px;
            }}
            .footer {{
                margin-top: 40px;
                padding-top: 20px;
                border-top: 2px solid #e5e7eb;
                text-align: center;
                color: #666;
                font-size: 12px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 15px 0;
            }}
            th, td {{
                padding: 10px;
                text-align: left;
                border-bottom: 1px solid #e5e7eb;
            }}
            th {{
                background: #f3f4f6;
                font-weight: bold;
            }}
        </style>
    </head>
    <body>
        <!-- Header -->
        <div class="header">
            <div style="display: flex; align-items: center; justify-content: center; gap: 20px; margin-bottom: 20px;">
                <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px; color: white;">
                    <span>🛡️</span>
                </div>
                <div style="text-align: left;">
                    <h1 style="margin: 0; font-size: 28px;">LAPORAN ASSESSMENT KEAMANAN</h1>
                    <p style="margin: 5px 0 0 0; color: #6366f1; font-weight: bold; font-size: 16px;">Obscura Node Security Team</p>
                </div>
            </div>
            <p class="subtitle">Obscura Security Hunter v2.0</p>
            <p class="subtitle">Comprehensive Security Assessment Report</p>
        </div>
        
        <!-- Informasi Target -->
        <div class="info-box">
            <h3>Informasi Target</h3>
            <table>
                <tr>
                    <th style="width: 30%">URL Target</th>
                    <td><span class="url-link">{target_url}</span></td>
                </tr>
                <tr>
                    <th>Tanggal Scan</th>
                    <td>{datetime.fromisoformat(scan_time.replace('Z', '+00:00')).strftime('%d %B %Y, %H:%M:%S WIB')}</td>
                </tr>
                <tr>
                    <th>ID Scan</th>
                    <td><code>{scan_id}</code></td>
                </tr>
                <tr>
                    <th>Scanner</th>
                    <td>Obscura Security Hunter - Platform Keamanan Siber</td>
                </tr>
            </table>
        </div>
        
        <!-- Ringkasan Eksekutif -->
        <div class="info-box">
            <h3>Ringkasan Eksekutif</h3>
            <p>Assessment keamanan ini dilakukan untuk mengidentifikasi celah keamanan pada aplikasi web target. 
            Scanner melakukan pengujian terhadap 8 fase testing yang mencakup reconnaissance, API security, 
            cloud misconfiguration, business logic, authentication, backend vulnerabilities, security headers, 
            dan SSL/TLS security.</p>
        </div>
        
        <!-- Summary Statistics -->
        <h2 style="color: #2563eb; margin-top: 30px;">Statistik Temuan</h2>
        <div class="summary-grid">
            <div class="summary-card critical">
                <h2>{total_critical}</h2>
                <p>CRITICAL</p>
            </div>
            <div class="summary-card high">
                <h2>{total_high}</h2>
                <p>HIGH</p>
            </div>
            <div class="summary-card medium">
                <h2>{total_medium}</h2>
                <p>MEDIUM</p>
            </div>
            <div class="summary-card low">
                <h2>{total_low}</h2>
                <p>LOW</p>
            </div>
        </div>
        
        <p><strong>Total Temuan:</strong> {total_vulns} vulnerability/vulnerabilities teridentifikasi</p>
    """
    
    # Detail Findings per Phase
    html += """
        <h2 style="color: #2563eb; margin-top: 30px; page-break-before: always;">Detail Temuan Keamanan</h2>
    """
    
    for idx, finding in enumerate(findings, 1):
        phase = finding.get('phase', f'Phase {idx}')
        status = finding.get('status', 'completed')
        vulnerabilities = finding.get('vulnerabilities', [])
        info = finding.get('info', {})
        
        html += f"""
        <div class="finding">
            <div class="finding-header">
                {idx}. {phase}
            </div>
            <p><strong>Status:</strong> {status.title()}</p>
        """
        
        # Show info if available
        if info and not vulnerabilities:
            html += "<h4>Informasi Teknologi:</h4><table>"
            for key, value in info.items():
                if isinstance(value, list):
                    value = '<br>'.join(str(v) for v in value)
                html += f"<tr><th style='width: 30%'>{key.replace('_', ' ').title()}</th><td>{value}</td></tr>"
            html += "</table>"
        
        # Show vulnerabilities
        if vulnerabilities:
            html += f"<p><strong>Jumlah Temuan:</strong> {len(vulnerabilities)} vulnerability/vulnerabilities</p>"
            
            for vuln in vulnerabilities:
                severity = vuln.get('severity', 'LOW').lower()
                vuln_type = vuln.get('type', 'Unknown Vulnerability')
                evidence = vuln.get('evidence', '')
                endpoint = vuln.get('endpoint', '')
                file_path = vuln.get('file', '')
                header = vuln.get('header', '')
                cve_id = vuln.get('cve_id', '')
                affected = vuln.get('affected_component', '')
                recommendation = vuln.get('recommendation', '')
                
                html += f"""
                <div class="vulnerability {severity}">
                    <div>
                        <span class="badge {severity}">{severity.upper()}</span>
                        <strong>{vuln_type}</strong>
                    </div>
                """
                
                if cve_id:
                    html += f"<p><strong>CVE ID:</strong> <code>{cve_id}</code></p>"
                
                if affected:
                    html += f"<p><strong>Komponen Terpengaruh:</strong> {affected}</p>"
                
                if endpoint:
                    full_url = target_url + endpoint
                    html += f"<p><strong>URL:</strong> <span class='url-link'>{full_url}</span></p>"
                
                if file_path:
                    full_url = target_url + file_path
                    html += f"<p><strong>File:</strong> <span class='url-link'>{full_url}</span></p>"
                
                if header:
                    html += f"<p><strong>Header:</strong> <code>{header}</code></p>"
                
                if evidence:
                    html += f"""
                    <div class="evidence">
                        <strong>Evidence / Penjelasan:</strong><br>
                        {evidence}
                    </div>
                    """
                
                if recommendation:
                    html += f"""
                    <div class="evidence" style="background: #fef3c7;">
                        <strong>⚠️ Rekomendasi:</strong><br>
                        {recommendation}
                    </div>
                    """
                
                html += "</div>"
        else:
            html += "<p style='color: #10b981;'>✓ Tidak ada vulnerability ditemukan pada fase ini.</p>"
        
        html += "</div>"
    
    # Recommendations Section
    html += """
        <h2 style="color: #2563eb; margin-top: 30px; page-break-before: always;">Rekomendasi Umum</h2>
        <div class="info-box">
            <h3>Langkah-Langkah Perbaikan</h3>
            <ol>
                <li><strong>Prioritaskan CRITICAL & HIGH findings:</strong> Perbaiki segera vulnerability dengan severity CRITICAL dan HIGH karena memiliki dampak keamanan yang signifikan.</li>
                <li><strong>Implementasi Security Headers:</strong> Pastikan semua security headers yang direkomendasikan sudah terpasang dengan konfigurasi yang benar.</li>
                <li><strong>Update Software:</strong> Selalu gunakan versi terbaru dari semua software, framework, dan library untuk menghindari CVE yang sudah diketahui.</li>
                <li><strong>Proteksi File Sensitif:</strong> Pastikan file konfigurasi (.env, config.php, dll) tidak accessible dari public.</li>
                <li><strong>Disable Directory Listing:</strong> Nonaktifkan directory listing pada web server.</li>
                <li><strong>Implementasi WAF:</strong> Pertimbangkan penggunaan Web Application Firewall untuk proteksi tambahan.</li>
                <li><strong>Regular Security Audit:</strong> Lakukan security assessment secara berkala minimal 3 bulan sekali.</li>
            </ol>
        </div>
    """
    
    # Footer
    html += f"""
        <div class="footer">
            <div style="text-align: center; margin-bottom: 20px;">
                <h3 style="background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; font-weight: 800; margin-bottom: 10px;">Obscura Node</h3>
                <p style="margin: 5px 0;"><strong>Obscura Security Hunter v2.0</strong></p>
            </div>
            <p>Platform Keamanan Siber dengan Zero False Positive</p>
            <p>Developer: Mas L | Email: digitalforensics.id@gmail.com</p>
            <p>Kartika Cyber Hackathon 2026 - Kategori Dukungan Teknologi</p>
            <p style="margin-top: 20px; font-size: 10px;">
                Report generated: {datetime.now().strftime('%d %B %Y, %H:%M:%S WIB')}<br>
                © 2026 Obscura Node - Obscura Security Hunter. All rights reserved.
            </p>
        </div>
    </body>
    </html>
    """
    
    return html
