// Obscura Security Hunter - Scanner JavaScript
// Fixes jQuery loading issue

$(document).ready(function() {
    console.log('[DEBUG] Scanner.js loaded, jQuery version:', $.fn.jquery);
    
    let currentScanId = null;
    let pollInterval = null;
    let selectedMode = 'deep'; // Default mode
    let pollDelay = 500; // Start with 500ms
    const maxPollDelay = 5000; // Max 5 seconds

    // Scan mode card selection
    $('.scan-mode-card').on('click', function() {
        // Remove active from all
        $('.scan-mode-card').removeClass('active');
        // Add active to clicked
        $(this).addClass('active');
        // Update selected mode
        selectedMode = $(this).data('mode');
        // Check the corresponding radio
        $('#mode' + selectedMode.charAt(0).toUpperCase() + selectedMode.slice(1)).prop('checked', true);
        
        // Show/hide extreme warning
        if (selectedMode === 'extreme') {
            $('#extremeWarning').slideDown();
        } else {
            $('#extremeWarning').slideUp();
        }
        
        console.log('[DEBUG] Selected scan mode:', selectedMode);
    });

    // Form submit handler
    $('#scanForm').on('submit', function(e) {
        e.preventDefault();
        startScan();
    });

    // Start scan function
    function startScan() {
        const targetUrl = $('#targetUrl').val().trim();
        
        console.log('[DEBUG] startScan called with URL:', targetUrl, 'mode:', selectedMode);
        
        if (!targetUrl) {
            alert('Please enter a target URL');
            return;
        }
        
        // Show progress, hide results
        $('#progressSection').show();
        $('#resultsSection').hide();
        $('#startScanBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Scanning...');
        
        console.log('[DEBUG] Sending POST to /api/scan');
        
        // Start scan with selected mode
        $.ajax({
            url: '/api/scan',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ 
                target_url: targetUrl,
                scan_mode: selectedMode 
            }),
            success: function(response) {
                console.log('[DEBUG] Scan response:', response);
                if (response.success) {
                    currentScanId = response.scan_id;
                    $('#scanId').text(currentScanId);
                    $('#scanTarget').text(targetUrl);
                    $('#scanStarted').text(new Date().toLocaleString());
                    
                    // Reset poll delay for new scan
                    pollDelay = 500;
                    
                    console.log('[DEBUG] Starting poll interval for scan_id:', currentScanId, 'mode:', response.scan_mode);
                    // Start polling for progress with exponential backoff
                    pollInterval = setInterval(checkProgress, pollDelay);
                } else {
                    console.error('[ERROR] Scan failed:', response.error);
                    alert('Failed to start scan: ' + response.error);
                    resetForm();
                }
            },
            error: function(xhr, status, error) {
                console.error('[ERROR] AJAX error:', status, error, xhr);
                alert('Error starting scan: ' + (xhr.responseText || error));
                resetForm();
            }
        });
    }

    // Check progress function with exponential backoff
    function checkProgress() {
        if (!currentScanId) {
            console.warn('[DEBUG] checkProgress called but no currentScanId');
            return;
        }
        
        $.get('/api/scan/' + currentScanId + '/status', function(response) {
            console.log('[DEBUG] Status update:', response);
            if (response.success) {
                const status = response.status;
                
                // Update progress
                $('#progressMessage').text(status.message);
                $('#progressPercent').text(status.progress + '%');
                $('#progressBar').css('width', status.progress + '%');
                
                if (status.status === 'completed') {
                    console.log('[DEBUG] Scan completed, loading results');
                    clearInterval(pollInterval);
                    loadResults();
                } else if (status.status === 'failed') {
                    console.error('[ERROR] Scan failed:', status.message);
                    clearInterval(pollInterval);
                    alert('Scan failed: ' + status.message);
                    resetForm();
                } else {
                    // Increase poll delay with exponential backoff
                    if (pollDelay < maxPollDelay) {
                        clearInterval(pollInterval);
                        pollDelay = Math.min(pollDelay * 2, maxPollDelay);
                        console.log('[DEBUG] Increasing poll delay to', pollDelay, 'ms');
                        pollInterval = setInterval(checkProgress, pollDelay);
                    }
                }
            }
        }).fail(function(xhr, status, error) {
            console.error('[ERROR] Failed to check progress:', status, error);
        });
    }

    // Load results function
    function loadResults() {
        $.get('/api/scan/' + currentScanId + '/results', function(response) {
            if (response.success) {
                const results = response.results;
                
                // Hide progress, show results
                $('#progressSection').hide();
                $('#resultsSection').show();
                $('#startScanBtn').prop('disabled', false).html('<i class="fas fa-rocket"></i> Start Scan');
                
                // Count vulnerabilities from findings
                let criticalCount = results.summary ? results.summary.critical : 0;
                let highCount = results.summary ? results.summary.high : 0;
                let mediumCount = results.summary ? results.summary.medium : 0;
                let lowCount = results.summary ? results.summary.low : 0;
                let totalVulns = criticalCount + highCount + mediumCount + lowCount;
                
                // Update counts
                $('#verifiedCount').text(totalVulns);
                $('#potentialCount').text('0');
                
                // Display findings
                if (results.findings && results.findings.length > 0) {
                    let html = '';
                    results.findings.forEach(function(finding, index) {
                        html += '<div class="card mb-3">';
                        html += '<div class="card-header bg-primary text-white">';
                        html += '<strong>' + (finding.phase || 'Phase ' + (index + 1)) + '</strong>';
                        html += '</div>';
                        html += '<div class="card-body">';
                        
                        if (finding.status) {
                            html += '<p><strong>Status:</strong> ' + finding.status + '</p>';
                        }
                        
                        if (finding.vulnerabilities && finding.vulnerabilities.length > 0) {
                            html += '<div class="mt-2"><strong>Vulnerabilities Found:</strong><ul class="list-unstyled">';
                            finding.vulnerabilities.forEach(function(v) {
                                html += '<li class="mb-3 p-3 border rounded">';
                                html += '<div class="mb-2">';
                                html += '<span class="badge badge-custom badge-' + v.severity.toLowerCase() + ' me-2">' + v.severity + '</span>';
                                html += '<strong>' + v.type + '</strong>';
                                html += '</div>';
                                
                                // Show clickable URL if endpoint/file exists
                                if (v.endpoint) {
                                    var fullUrl = results.target_url + v.endpoint;
                                    html += '<p class="mb-1"><strong>URL:</strong> <a href="' + fullUrl + '" target="_blank" rel="noopener" class="text-break">' + fullUrl + '</a> <i class="fas fa-external-link-alt"></i></p>';
                                } else if (v.file) {
                                    var fullUrl = results.target_url + v.file;
                                    html += '<p class="mb-1"><strong>File:</strong> <a href="' + fullUrl + '" target="_blank" rel="noopener" class="text-break">' + fullUrl + '</a> <i class="fas fa-external-link-alt"></i></p>';
                                }
                                
                                if (v.header) {
                                    html += '<p class="mb-1"><strong>Header:</strong> <code>' + v.header + '</code></p>';
                                }
                                
                                if (v.evidence) {
                                    html += '<p class="mb-0 text-muted"><small><strong>Evidence:</strong><br>' + v.evidence + '</small></p>';
                                }
                                
                                html += '</li>';
                            });
                            html += '</ul></div>';
                        } else {
                            html += '<p class="text-muted">No vulnerabilities found in this phase.</p>';
                        }
                        
                        if (finding.info) {
                            html += '<pre class="mt-2">' + JSON.stringify(finding.info, null, 2) + '</pre>';
                        }
                        
                        html += '</div></div>';
                    });
                    $('#verifiedList').html(html);
                } else {
                    $('#verifiedList').html('<div class="alert alert-success"><i class="fas fa-check-circle"></i> No vulnerabilities found. Target appears to be secure!</div>');
                }
                
                // Hide potential section
                $('#potentialVulns').hide();
            }
        }).fail(function() {
            alert('Failed to load results. Please try again.');
            resetForm();
        });
    }

    // Reset form function
    function resetForm() {
        $('#startScanBtn').prop('disabled', false).html('<i class="fas fa-rocket"></i> Start Scan');
        $('#progressSection').hide();
        $('#resultsSection').hide();
        currentScanId = null;
        pollDelay = 500; // Reset poll delay
        if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
        }
    }

    // New scan button
    $('#newScan').on('click', function() {
        resetForm();
        $('#targetUrl').val('').focus();
    });

    // Download report button
    $('#downloadReport').on('click', function() {
        if (currentScanId) {
            // Use download endpoint instead of results endpoint
            window.location.href = '/api/scan/' + currentScanId + '/download';
        } else {
            alert('No scan results available to download');
        }
    });

    // Download PDF report button
    $('#downloadPDF').on('click', function() {
        if (currentScanId) {
            // Open PDF in new tab (can be printed to PDF)
            window.open('/api/scan/' + currentScanId + '/pdf', '_blank');
        } else {
            alert('No scan results available to download');
        }
    });

    console.log('[DEBUG] Scanner.js initialization complete');
});
