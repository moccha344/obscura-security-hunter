#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Obscura Security Hunter - Web Application
Flask-based web interface for security scanning

Author: Mas L
Email: digitalforensics.id@gmail.com
"""

from flask import Flask, render_template, request, jsonify, send_file, session, make_response
import os
import sys
import json
import threading
import time
import requests
from datetime import datetime
from pathlib import Path
import secrets
import warnings

# Suppress SSL warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import our scanners
scanner_modules = {}
try:
    from simple_scanner import SimpleScanner
    scanner_modules['simple'] = SimpleScanner
    print("[OK] Simple Scanner loaded")
except Exception as e:
    print(f"[!] Simple Scanner not available: {e}")

try:
    from deep_scanner import DeepScanner
    scanner_modules['deep'] = DeepScanner
    print("[OK] Deep Scanner loaded")
except Exception as e:
    print(f"[!] Deep Scanner not available: {e}")

try:
    from extreme_scanner import ExtremeScanner
    scanner_modules['extreme'] = ExtremeScanner
    print("[OK] Extreme Scanner loaded")
except Exception as e:
    print(f"[!] Extreme Scanner not available: {e}")

scanner_available = len(scanner_modules) > 0
print(f"[*] Available scan modes: {list(scanner_modules.keys())}")

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

# Global storage for scan results (in production, use database)
scan_results = {}
scan_status = {}

@app.route('/')
def index():
    """Main dashboard"""
    return render_template('index.html')

@app.route('/scanner')
def scanner():
    """Scanner page"""
    return render_template('scanner.html')

@app.route('/manual-verify')
def manual_verify():
    """Manual verification page"""
    return render_template('manual_verify.html')

@app.route('/results')
def results():
    """Results page"""
    return render_template('results.html')

@app.route('/documentation')
def documentation():
    """Documentation page"""
    return render_template('documentation.html')

@app.route('/api/scan', methods=['POST'])
def api_scan():
    """API endpoint to start a scan"""
    try:
        data = request.get_json()
        target_url = data.get('target_url', '').strip()
        scan_mode = data.get('scan_mode', 'deep').lower()  # simple, deep, extreme
        
        if not target_url:
            return jsonify({'success': False, 'error': 'Target URL is required'}), 400
        
        # Validate scan mode
        if scan_mode not in scanner_modules:
            # Fallback to available scanner
            if scanner_modules:
                scan_mode = list(scanner_modules.keys())[0]
            else:
                return jsonify({'success': False, 'error': 'No scanner available'}), 500
        
        # Add protocol if missing
        if not target_url.startswith(('http://', 'https://')):
            target_url = 'https://' + target_url
        
        # Generate scan ID
        scan_id = secrets.token_hex(8)
        
        # Initialize scan status
        scan_status[scan_id] = {
            'status': 'running',
            'progress': 0,
            'message': 'Initializing scan...',
            'started_at': datetime.now().isoformat(),
            'target': target_url,
            'scan_mode': scan_mode
        }
        
        # Start scan in background thread
        thread = threading.Thread(target=run_scan, args=(scan_id, target_url, scan_mode))
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'scan_id': scan_id,
            'scan_mode': scan_mode,
            'message': 'Scan started successfully'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

def run_scan(scan_id, target_url, scan_mode='deep'):
    """Run scan in background with selected mode (simple/deep/extreme)"""
    try:
        scan_status[scan_id]['message'] = f'Initializing {scan_mode.upper()} Scanner...'
        scan_status[scan_id]['progress'] = 5
        
        # Check if scanner available
        if scanner_available and scan_mode in scanner_modules:
            try:
                # Progress callback
                def progress_callback(phase, message):
                    scan_status[scan_id]['message'] = f"{phase}: {message}"
                    
                    # Update progress based on mode and phase
                    if scan_mode == 'simple':
                        progress_map = {
                            'Phase 1': 25, 'Phase 2': 50, 'Phase 3': 75, 'Phase 4': 90
                        }
                    elif scan_mode == 'deep':
                        progress_map = {
                            'Phase 1': 15, 'Phase 2': 30, 'Phase 3': 45, 'Phase 4': 55,
                            'Phase 5': 65, 'Phase 6': 75, 'Phase 7': 85, 'Phase 8': 90, 'Phase 9': 95
                        }
                    else:  # extreme
                        progress_map = {
                            'Phase 1': 2, 'Phase 2': 4, 'Phase 3': 6, 'Phase 4': 8,
                            'Phase 5': 10, 'Phase 6': 12, 'Phase 7': 14, 'Phase 8': 16,
                            'Phase 9': 18, 'Phase 10': 20, 'Phase 11': 22, 'Phase 12': 24,
                            'Phase 13': 26, 'Phase 14': 28, 'Phase 15': 30, 'Phase 16': 32,
                            'Phase 17': 34, 'Phase 18': 36, 'Phase 19': 38, 'Phase 20': 40,
                            'Phase 21': 42, 'Phase 22': 44, 'Phase 23': 46, 'Phase 24': 48,
                            'Phase 25': 50, 'Phase 26': 52, 'Phase 27': 54, 'Phase 28': 56,
                            'Phase 29': 58, 'Phase 30': 60, 'Phase 31': 62, 'Phase 32': 64,
                            'Phase 33': 66, 'Phase 34': 68, 'Phase 35': 70, 'Phase 36': 72,
                            'Phase 37': 74, 'Phase 38': 75, 'Phase 39': 76, 'Phase 40': 77,
                            'Phase 41': 78, 'Phase 42': 79, 'Phase 43': 80, 'Phase 44': 81,
                            'Phase 45': 82, 'Phase 46': 84, 'Phase 47': 86, 'Phase 48': 88,
                            'Phase 49': 90, 'Phase 50': 92, 'Phase 51': 94, 'Phase 52': 95,
                            'Phase 53': 96, 'Phase 54': 97, 'Phase 55': 98,
                            'BRUTAL': 70, 'ULTIMATE': 82, 'ARSENAL': 90, 'ELITE': 98, 'COMPLETE': 100
                        }
                    
                    for p, val in progress_map.items():
                        if p in phase:
                            scan_status[scan_id]['progress'] = val
                            break
                
                # Initialize selected scanner
                ScannerClass = scanner_modules[scan_mode]
                scanner = ScannerClass(target_url, scan_id=scan_id, callback=progress_callback)
                
                # Run appropriate scan method
                scan_status[scan_id]['message'] = f'Starting {scan_mode} vulnerability scan...'
                
                if scan_mode == 'simple':
                    results = scanner.run_scan()
                elif scan_mode == 'deep':
                    results = scanner.run_deep_scan()
                else:  # extreme
                    results = scanner.run_extreme_scan()
                
                # Process results
                results['scan_id'] = scan_id
                results['scan_mode'] = scan_mode
                results['completed_at'] = datetime.now().isoformat()
                results['target_url'] = target_url
                
                # SUCCESS!
                scan_status[scan_id]['status'] = 'completed'
                scan_status[scan_id]['message'] = f'Scan completed! Found {len(results["findings"])} issues'
                scan_status[scan_id]['progress'] = 100
                scan_results[scan_id] = results
                
            except Exception as e:
                # Scanner failed
                scan_status[scan_id]['status'] = 'failed'
                scan_status[scan_id]['message'] = f'Scanner error: {str(e)}'
                scan_status[scan_id]['progress'] = 0
                scan_results[scan_id] = {
                    'error': str(e),
                    'target_url': target_url,
                    'scan_mode': scan_mode,
                    'findings': []
                }
        else:
            # No scanner available - basic test
            scan_status[scan_id]['message'] = 'Scanner not available'
            scan_status[scan_id]['progress'] = 50
            
            try:
                response = requests.get(target_url, timeout=10, verify=False)
                results = {
                    'target_url': target_url,
                    'scan_id': scan_id,
                    'scan_mode': scan_mode,
                    'findings': [{
                        'phase': 'Basic HTTP Test',
                        'info': {
                            'status_code': response.status_code,
                            'response_time': response.elapsed.total_seconds()
                        }
                    }],
                    'summary': {
                        'total_tests': 1,
                        'critical': 0,
                        'high': 0,
                        'medium': 0,
                        'low': 0
                    }
                }
            except Exception as e:
                results = {
                    'target_url': target_url,
                    'scan_id': scan_id,
                    'scan_mode': scan_mode,
                    'findings': [{
                        'phase': 'Basic HTTP Test',
                        'info': {'error': str(e)}
                    }],
                    'summary': {
                        'total_tests': 1,
                        'critical': 0,
                        'high': 0,
                        'medium': 0,
                        'low': 0
                    }
                }
            
            scan_status[scan_id]['status'] = 'completed'
            scan_status[scan_id]['message'] = 'Basic test completed'
            scan_status[scan_id]['progress'] = 100
            scan_results[scan_id] = results
            
    except Exception as e:
        # Fatal error
        scan_status[scan_id]['status'] = 'failed'
        scan_status[scan_id]['message'] = f'Fatal error: {str(e)}'
        scan_status[scan_id]['progress'] = 0
        scan_results[scan_id] = {'error': str(e), 'scan_mode': scan_mode}

@app.route('/api/scan/<scan_id>/status', methods=['GET'])
def api_scan_status(scan_id):
    """Get scan status"""
    if scan_id not in scan_status:
        return jsonify({'success': False, 'error': 'Scan not found'}), 404
    
    return jsonify({
        'success': True,
        'status': scan_status[scan_id]
    })

@app.route('/api/scan/<scan_id>/results', methods=['GET'])
def api_scan_results(scan_id):
    """Get scan results"""
    if scan_id not in scan_results:
        return jsonify({'success': False, 'error': 'Results not found'}), 404
    
    return jsonify({
        'success': True,
        'results': scan_results[scan_id]
    })

@app.route('/api/scan/<scan_id>/download', methods=['GET'])
def api_scan_download(scan_id):
    """Download scan results as JSON file"""
    if scan_id not in scan_results:
        return jsonify({'success': False, 'error': 'Results not found'}), 404
    
    results = scan_results[scan_id]
    
    # Create JSON response with download headers
    response = jsonify(results)
    response.headers['Content-Disposition'] = f'attachment; filename=scan_report_{scan_id}.json'
    response.headers['Content-Type'] = 'application/json'
    
    return response

@app.route('/api/scan/<scan_id>/pdf', methods=['GET'])
def api_scan_pdf(scan_id):
    """Generate and download PDF report in Indonesian"""
    if scan_id not in scan_results:
        return jsonify({'success': False, 'error': 'Results not found'}), 404
    
    try:
        results = scan_results[scan_id]
        
        # Generate HTML report
        html_content = generate_html_report(results, scan_id)
        
        # For now, return HTML (can be printed to PDF in browser)
        # Or use weasyprint/pdfkit for server-side PDF generation
        response = make_response(html_content)
        response.headers['Content-Type'] = 'text/html; charset=utf-8'
        response.headers['Content-Disposition'] = f'inline; filename=laporan_keamanan_{scan_id}.html'
        
        return response
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/verify', methods=['POST'])
def api_verify():
    """Manual verification endpoint"""
    try:
        data = request.get_json()
        vuln_type = data.get('vuln_type')
        target_url = data.get('target_url')
        payload = data.get('payload')
        
        if not all([vuln_type, target_url]):
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400
        
        # Basic verification
        result = {
            'vuln_type': vuln_type,
            'target_url': target_url,
            'payload': payload,
            'verified': False,
            'message': 'Manual verification not yet implemented'
        }
        
        return jsonify({
            'success': True,
            'verification_result': result
        })
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    print("\n" + "="*70)
    print("Obscura Security Hunter - Web Application")
    print("="*70)
    print("\n[*] Starting Flask server...")
    print("[*] Access dashboard at: http://localhost:5000")
    print("\n[*] Press Ctrl+C to stop")
    print("="*70 + "\n")
    
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)
