@echo off
echo ========================================
echo Ultimate Security Hunter - Web Server
echo ========================================
echo.
echo Starting Flask server...
echo Access: http://localhost:5000
echo.
echo Press CTRL+C to stop server
echo ========================================
echo.

cd /d "%~dp0"
python app.py

pause
