# 🎯 NO HALLUCINATION RULES - Obscura Security Hunter

## PENTING: SEMUA FINDINGS HARUS REAL & VERIFIED

Setiap vulnerability yang dilaporkan HARUS memiliki **EVIDENCE NYATA**. Tidak boleh ada halusinasi atau asumsi.

---

## ✅ Rules untuk Setiap Teknik

### 1. **SQL Injection**
**WAJIB:**
- ✅ Kirim payload yang berbeda → dapat response yang berbeda
- ✅ Boolean-based: `' AND '1'='1` (true) vs `' AND '1'='2` (false) → response berbeda
- ✅ Time-based: Measure response time → jika delay detected = vulnerable
- ✅ Error-based: Lihat actual database error di response

**DILARANG:**
- ❌ Report hanya karena parameter exists
- ❌ Report tanpa verifikasi response difference

---

### 2. **XSS (Cross-Site Scripting)**
**WAJIB:**
- ✅ Payload reflected EXACTLY di response HTML
- ✅ Check context: di dalam `<script>`, HTML tag, attribute
- ✅ Verify payload tidak ter-encode/escape

**DILARANG:**
- ❌ Report jika payload ter-encode (`<` jadi `&lt;`)
- ❌ Report jika payload tidak reflected
- ❌ Report tanpa verify context

**Evidence:**
```
Payload: <script>alert(1)</script>
Response contains: <script>alert(1)</script> (UNENCODED)
→ REAL XSS ✅

Payload: <script>alert(1)</script>
Response contains: &lt;script&gt;alert(1)&lt;/script&gt; (ENCODED)
→ NOT VULNERABLE ❌
```

---

### 3. **SSRF (Server-Side Request Forgery)**
**WAJIB:**
- ✅ Response mengandung content dari internal URL
- ✅ Metadata endpoint: response contains `ami-id`, `instance-id`, `computeMetadata`
- ✅ Internal service: response contains service-specific content

**DILARANG:**
- ❌ Report hanya karena parameter accepts URL
- ❌ Report tanpa verify actual internal access

---

### 4. **Subdomain Takeover**
**WAJIB:**
- ✅ DNS resolves ke service yang CONFIRMED mati
- ✅ Response contains EXACT error message: "No such app", "NoSuchBucket", "404 Web Site not found"
- ✅ Verify service provider dan error signature

**DILARANG:**
- ❌ Report tanpa DNS check
- ❌ Report subdomain yang active

---

### 5. **Prototype Pollution**
**WAJIB:**
- ✅ Send pollution payload
- ✅ Follow-up request shows polluted property PERSISTED
- ✅ Verify `polluted`, `isAdmin`, or injected property appears in subsequent response

**DILARANG:**
- ❌ Report hanya karena API accepts JSON
- ❌ Report tanpa follow-up verification

---

### 6. **HTTP Request Smuggling**
**WAJIB:**
- ✅ Send smuggling payload
- ✅ Follow-up request shows DIFFERENT behavior (affected by smuggled request)
- ✅ Evidence: `/admin` content in normal request, or 403→200 status change

**DILARANG:**
- ❌ Report tanpa follow-up request verification
- ❌ Assume vulnerability dari response code saja

---

### 7. **Cache Poisoning**
**WAJIB:**
- ✅ Inject unkeyed header dengan malicious value
- ✅ Response includes Cache headers: `X-Cache: HIT`, `CF-Cache-Status`, `Age`
- ✅ Malicious value REFLECTED in cached response

**DILARANG:**
- ❌ Report tanpa verify cache
- ❌ Report jika tidak ada cache headers

---

### 8. **XXE (XML External Entity)**
**WAJIB:**
- ✅ Send XXE payload
- ✅ Response contains FILE CONTENT dari external entity
- ✅ Example: `/etc/passwd` content, or URL fetch result

**DILARANG:**
- ❌ Report hanya karena endpoint accepts XML
- ❌ Report tanpa verify entity expansion

---

### 9. **SSTI (Server-Side Template Injection)**
**WAJIB:**
- ✅ Send math expression: `{{7*7}}`
- ✅ Response contains COMPUTED result: `49`
- ✅ Verify template engine executed code

**DILARANG:**
- ❌ Report jika response masih `{{7*7}}` (not executed)
- ❌ Report tanpa verify execution

**Evidence:**
```
Payload: {{7*7}}
Response: 49
→ SSTI CONFIRMED ✅

Payload: {{7*7}}
Response: {{7*7}}
→ NOT VULNERABLE ❌
```

---

### 10. **NoSQL Injection**
**WAJIB:**
- ✅ Send NoSQL operator: `{"$ne":null}`
- ✅ Response shows DIFFERENT data (bypass authentication, return more records)
- ✅ Verify behavior change

**DILARANG:**
- ❌ Report tanpa verify behavior change
- ❌ Assume vulnerability dari syntax acceptance

---

### 11. **JWT Vulnerabilities**
**WAJIB:**
- ✅ Found JWT token in response/cookie
- ✅ Decode and show structure
- ✅ Test specific vulnerability:
  - Algorithm confusion: Change `alg` to `none` → still accepted
  - Weak secret: Successfully crack with common wordlist
  - No expiry: Token has no `exp` claim

**DILARANG:**
- ❌ Report hanya karena JWT exists
- ❌ Report tanpa actual attack verification

---

### 12. **Path Traversal**
**WAJIB:**
- ✅ Send traversal payload: `../../etc/passwd`
- ✅ Response contains FILE CONTENT: `root:x:0:0:`
- ✅ Verify actual file read

**DILARANG:**
- ❌ Report tanpa verify file content
- ❌ Report dari 404 atau error messages

---

### 13. **Command Injection**
**WAJIB:**
- ✅ Send command: `; sleep 5`
- ✅ Measure response time → actual delay detected
- ✅ OR: Response contains command output

**DILARANG:**
- ❌ Report tanpa timing verification atau output

---

### 14. **Insecure Deserialization**
**WAJIB:**
- ✅ Find serialized data in cookies/parameters
- ✅ Send malicious serialized object
- ✅ Verify execution (RCE indicator or behavior change)

**DILARANG:**
- ❌ Report tanpa verify deserialization execution

---

### 15. **GraphQL Introspection**
**WAJIB:**
- ✅ Send introspection query
- ✅ Response contains `__schema` object with types/fields
- ✅ Actual schema disclosed

**DILARANG:**
- ❌ Report tanpa verify schema in response

---

### 16. **Session Fixation**
**WAJIB:**
- ✅ Set custom session ID
- ✅ "Login" (or access protected resource)
- ✅ Verify custom session ID PERSISTS after login

**DILARANG:**
- ❌ Report tanpa verify persistence

---

### 17. **File Upload Bypass**
**WAJIB:**
- ✅ Upload malicious file (PHP shell, SVG XSS)
- ✅ File is ACCEPTED (not rejected)
- ✅ File is ACCESSIBLE via URL
- ✅ File executes (for PHP/JSP) or triggers XSS (for SVG)

**DILARANG:**
- ❌ Report jika file rejected
- ❌ Report tanpa verify file accessible

---

### 18. **CRLF Injection**
**WAJIB:**
- ✅ Send CRLF payload: `%0d%0aSet-Cookie: evil=true`
- ✅ Response headers contain INJECTED header
- ✅ Verify actual header injection occurred

**DILARANG:**
- ❌ Report tanpa verify injected header in response

---

### 19. **Shadow API Discovery**
**WAJIB:**
- ✅ Endpoint EXISTS (200, 201, 401, 403)
- ✅ Response is JSON/API format
- ✅ Endpoint is NOT documented/expected

**OK to report** - this is info gathering, not exploitation

---

### 20. **Dependency Confusion**
**WAJIB:**
- ✅ Dependency file IS EXPOSED (200 status)
- ✅ File contains INTERNAL/PRIVATE package names
- ✅ Evidence: `@company/`, `@internal/`, `private-`

**DILARANG:**
- ❌ Report jika file not accessible (404)
- ❌ Report tanpa verify internal package names

---

### 21. **DNS Rebinding / Host Header Injection**
**WAJIB:**
- ✅ Send arbitrary Host header
- ✅ Server ACCEPTS and processes it (200 status)
- ✅ Response reflects arbitrary host

**DILARANG:**
- ❌ Report jika server rejects (400, 421)

---

### 22. **Security Headers Missing**
**WAJIB:**
- ✅ Check response headers
- ✅ List ACTUALLY missing headers
- ✅ Severity based on impact (X-Frame-Options = clickjacking risk)

**OK to report** - observable fact

---

### 23. **Sensitive File Exposure**
**WAJIB:**
- ✅ File accessible (200 status)
- ✅ File contains ACTUAL sensitive data
- ✅ Examples: `.git/config`, `.env`, `backup.sql`

**DILARANG:**
- ❌ Report 404 files
- ❌ Report empty responses

---

### 24. **Race Condition**
**WAJIB:**
- ✅ Send concurrent requests
- ✅ Verify DIFFERENT outcomes (e.g., balance went negative, coupon used twice)
- ✅ Evidence of race window exploitation

**DILARANG:**
- ❌ Report tanpa verify actual race condition exploitation

---

### 25. **LDAP/XPath Injection**
**WAJIB:**
- ✅ Send injection payload
- ✅ Response shows DIFFERENT data or authentication bypass
- ✅ Verify behavior change

**DILARANG:**
- ❌ Report tanpa verify actual injection effect

---

## 🔍 Verification Checklist

Before reporting ANY finding, ask:

1. **Did I receive ACTUAL evidence in the response?**
   - ✅ Yes → Report it
   - ❌ No → Don't report

2. **Is the evidence SPECIFIC to this vulnerability?**
   - ✅ Computed value (49 from 7*7) → Report
   - ❌ Generic error message → Don't report

3. **Can I REPRODUCE this finding?**
   - ✅ Yes, consistently → Report
   - ❌ Only happened once/randomly → Investigate more

4. **Is this a REAL security risk?**
   - ✅ Exploitation possible → Report
   - ❌ Just interesting behavior → Don't report

---

## 🚫 NEVER Report These (Hallucinations)

❌ Parameter exists but not vulnerable  
❌ Endpoint exists but protected  
❌ Header reflected but encoded  
❌ Input echoed but sanitized  
❌ Form found but no actual vulnerability  
❌ Error message but not exploitable  
❌ 404/403 responses  
❌ Timeouts without consistent verification  
❌ "Possible" without evidence  
❌ "Might be vulnerable to" without proof  

---

## ✅ Good Finding Examples

### Example 1: SQL Injection (REAL)
```
Title: SQL Injection in 'id' parameter
Severity: Critical
Evidence:
  - URL: http://target.com/user?id=1' AND '1'='1
  - Response length: 5234 bytes
  - URL: http://target.com/user?id=1' AND '1'='2
  - Response length: 0 bytes
  - Conclusion: Boolean-based blind SQLi confirmed
```

### Example 2: XSS (REAL)
```
Title: Reflected XSS in search parameter
Severity: High
Evidence:
  - Payload: <script>alert(1)</script>
  - Injected in: http://target.com/search?q=<script>alert(1)</script>
  - Response snippet: <h1>Results for <script>alert(1)</script></h1>
  - Context: HTML, unencoded
  - Conclusion: XSS confirmed
```

---

## ❌ Bad Finding Examples (Hallucinations)

### Example 1: False XSS
```
❌ Title: XSS in search parameter
Evidence:
  - Payload: <script>alert(1)</script>
  - Response: &lt;script&gt;alert(1)&lt;/script&gt;
  - Problem: PAYLOAD IS ENCODED → NOT VULNERABLE
```

### Example 2: False SQLi
```
❌ Title: Possible SQL Injection
Evidence:
  - Parameter 'id' accepts numeric input
  - Tested with: id=1'
  - Got: 500 error
  - Problem: Error alone doesn't confirm SQLi, need verification
```

---

## 🎯 Implementation in Code

```python
def add_finding_with_evidence(self, title, severity, evidence_dict):
    """
    Only add finding if we have REAL evidence
    
    Args:
        evidence_dict: Must contain actual proof:
            - 'payload': What was sent
            - 'response_snippet': What was received
            - 'proof': Why this confirms vulnerability
    """
    # Validate evidence exists
    if not all(k in evidence_dict for k in ['payload', 'response_snippet', 'proof']):
        self.log("SKIPPED", f"No sufficient evidence for: {title}")
        return False
    
    # Add the finding
    self.findings.append({
        'title': title,
        'severity': severity,
        'evidence': evidence_dict
    })
    return True
```

---

## 🏆 Goal: ZERO False Positives

**Our Promise:**
- Every finding in the report is REAL
- Every evidence is VERIFIABLE
- Every vulnerability is EXPLOITABLE
- NO hallucination
- NO assumptions
- NO "might be vulnerable"

**Quality over Quantity:**
- Better to find 5 REAL vulnerabilities than 50 false positives
- Judges will verify findings
- False positives = credibility loss
- Real findings = hackathon win 🏆

---

**Obscura Security Hunter - NO HALLUCINATION GUARANTEE**  
*If we report it, it's REAL.* ✅
