# 🎬 Panduan Recording Video untuk Hackathon Kartika 2026

## 📋 Persiapan Sebelum Recording

### 1. Software yang Dibutuhkan
- **OBS Studio** (https://obsproject.com/) - Recommended untuk screen recording
- **Browser** - Chrome/Edge/Firefox (pastikan tampilan full screen)
- **Text Editor** - Untuk show code (optional)

### 2. Persiapan Website Target
- ✅ Website Anda sendiri sudah ready
- ✅ Connection internet stabil
- ✅ Website accessible dan responsive
- ⚠️ **PENTING**: Pastikan Anda punya izin untuk scan website tersebut!

### 3. Test Run Dulu
```bash
# Jalankan command ini untuk test:
cd d:\Kumpulan_Tools\tool_bssn\web_app
python app.py
```
Atau double-click: `START_SERVER.bat`

Akses: http://localhost:5000

## 🎥 Skenario Video (5-10 menit)

### Scene 1: Opening (30 detik)
**Yang ditampilkan:**
- Judul: "Ultimate Security Hunter v2.0 - Platform Keamanan Siber dengan Zero False Positive"
- Your name: Mas L
- Email: digitalforensics.id@gmail.com
- Purpose: "Submission untuk Kartika Cyber Hackathon 2026"

**Narasi:**
> "Selamat pagi/siang/sore. Saya Mas L, dan ini adalah demonstrasi Ultimate Security Hunter versi 2.0, sebuah platform keamanan siber berbasis AI yang saya kembangkan untuk Hackathon Kartika 2026 kategori Dukungan Teknologi."

### Scene 2: Dashboard Overview (1 menit)
**Yang ditampilkan:**
- Buka http://localhost:5000
- Tunjukkan dashboard utama
- Explain features:
  - Automated Scanner (14 vulnerability types)
  - Manual Verification
  - Real-time Results
  - Zero False Positive guarantee

**Narasi:**
> "Platform ini memiliki 3 komponen utama: Scanner otomatis yang dapat mendeteksi 14 jenis vulnerability berbeda, Manual Verifier untuk validasi findings, dan Real-time reporting system."

### Scene 3: Live Scanning Demo (5-7 menit) ⭐ **MAIN CONTENT**
**Yang ditampilkan:**
1. Klik menu "Scanner"
2. Input target URL website Anda
3. Klik "Start Scan"
4. **SHOW REAL-TIME PROGRESS:**
   - Progress bar bergerak 0% → 100%
   - Status messages update:
     - "Testing Java Deserialization RCE..."
     - "Testing Python Pickle RCE..."
     - "Testing SQL Injection..."
     - "Testing SSRF..."
     - "Testing XXE..."
     - dll (14 phases)
5. Hasil scan muncul dengan details:
   - Verified vulnerabilities (if found)
   - Potential issues
   - Evidence untuk setiap finding

**Narasi untuk setiap fase:**
> "Scanner sedang melakukan testing terhadap 14 jenis vulnerability secara real-time. Ini bukan simulasi, tapi actual testing terhadap target website."

**Saat hasil muncul:**
> "Seperti yang Anda lihat, scanner berhasil mengidentifikasi [X] vulnerability dengan evidence yang jelas. Setiap finding dilengkapi dengan bukti konkret seperti response time, payload yang digunakan, dan cara verifikasinya."

### Scene 4: Manual Verification (1 menit)
**Yang ditampilkan:**
- Klik menu "Manual Verify"
- Pilih salah satu finding dari scan sebelumnya
- Show verification process
- Confirm hasil (verified/false positive)

**Narasi:**
> "Setiap finding bisa diverifikasi manual menggunakan built-in manual verifier. Ini memastikan zero false positive karena setiap vulnerability dikonfirmasi secara double-check."

### Scene 5: Results & Report (1 menit)
**Yang ditampilkan:**
- Klik menu "Results"
- Show summary statistics
- Download JSON report
- Buka file JSON, show struktur data

**Narasi:**
> "Hasil scan disimpan dalam format JSON yang terstruktur, siap untuk diintegrasikan dengan sistem lain atau sebagai dokumentasi untuk BSSN."

### Scene 6: Closing (30 detik)
**Yang ditampilkan:**
- Back to dashboard
- Show documentation page (optional)

**Narasi:**
> "Ultimate Security Hunter v2.0 ini dikembangkan untuk membantu tim keamanan dalam melakukan vulnerability assessment dengan akurasi tinggi dan zero false positive. Terima kasih atas perhatiannya, dan saya siap untuk Q&A."

## 🎯 Tips Recording yang Baik

### Video Quality
- **Resolution**: Minimal 1080p (1920x1080)
- **Frame Rate**: 30 fps atau 60 fps
- **Audio**: Clear voice, no background noise
- **Duration**: 5-10 menit (jangan terlalu panjang)

### OBS Studio Settings
```
Output:
- Recording Quality: High Quality, Medium File Size
- Recording Format: mp4
- Encoder: x264 atau NVENC (jika ada GPU Nvidia)

Video:
- Base Resolution: 1920x1080
- Output Resolution: 1920x1080
- FPS: 30

Audio:
- Sample Rate: 44.1 khz
- Channels: Stereo
```

### Screen Layout
- **Full screen browser** untuk demo
- **No desktop clutter** - close unnecessary windows
- **Dark mode** - easier on eyes
- **Zoom in** jika perlu untuk show details

### Voice Over
- **Speak clearly** dan tidak terburu-buru
- **Bahasa Indonesia** formal tapi friendly
- **Explain technical terms** jika perlu
- **Show enthusiasm** - ini project Anda!

## ⚠️ Hal yang HARUS DIHINDARI

❌ **JANGAN:**
- Record desktop yang berantakan
- Speak terlalu cepat atau mumbling
- Show data sensitif (passwords, API keys, personal info)
- Use musik copyrighted
- Recording dengan koneksi internet lambat (scan akan lama)

✅ **LAKUKAN:**
- Test run beberapa kali sebelum final recording
- Check audio quality dulu (record 30 detik test)
- Prepare notes/script kalau perlu
- Scan website yang response time-nya bagus
- Save multiple takes, pilih yang terbaik

## 📝 Checklist Sebelum Record

- [ ] OBS Studio installed dan tested
- [ ] Flask app running di http://localhost:5000
- [ ] Website target sudah di-test (accessible & fast)
- [ ] Browser dalam keadaan clean (no extra tabs)
- [ ] Script/notes sudah prepared
- [ ] Audio input tested (clear voice)
- [ ] Desktop clean, only necessary windows
- [ ] Recording folder has enough disk space (minimal 5GB)

## 🚀 Command untuk Start Recording

### 1. Start Flask Server
```bash
cd d:\Kumpulan_Tools\tool_bssn\web_app
python app.py
```
atau double-click: **START_SERVER.bat**

### 2. Open Browser
```
http://localhost:5000
```

### 3. Start OBS Recording
- Press **Start Recording** button
- Or hotkey: usually `Ctrl+Shift+R`

### 4. Do Your Demo
Follow skenario di atas!

### 5. Stop Recording
- Press **Stop Recording**
- File akan tersimpan di folder OBS output

## 🎬 Post-Production (Optional)

Jika mau edit video:
- **Cut parts yang tidak perlu** (mistakes, loading times)
- **Add intro/outro slide** dengan title & contact
- **Add background music** (gunakan royalty-free music)
- **Add captions** jika perlu (subtitle)

Software editing:
- **Free**: DaVinci Resolve, Shotcut
- **Paid**: Adobe Premiere, Camtasia

## 📤 Upload ke YouTube

1. **Title**: "Ultimate Security Hunter v2.0 - Kartika Cyber Hackathon 2026 Submission"
2. **Description**: 
```
Platform Keamanan Siber dengan Zero False Positive
Developed by: Mas L
Email: digitalforensics.id@gmail.com
Category: Dukungan Teknologi

Features:
- 14 Vulnerability Types Detection
- Real-time Scanning
- Manual Verification
- Zero False Positive Guarantee
- JSON Report Export

Submission for Kartika Cyber Hackathon 2026
```
3. **Tags**: `cybersecurity`, `security scanner`, `vulnerability assessment`, `kartika hackathon`, `penetration testing`, `bug bounty`, `bssn`
4. **Visibility**: **Unlisted** atau **Public** (tergantung requirements hackathon)

## 📊 5 Screenshots yang Diperlukan

1. **Dashboard** - Homepage dengan overview
2. **Scanner Page** - Input target & scan button
3. **Scanning Progress** - Real-time progress bar dengan status
4. **Results Page** - List of findings dengan details
5. **Report JSON** - Exported JSON file opened in text editor

Save dengan nama:
- `01_dashboard.png`
- `02_scanner_input.png`
- `03_scanning_progress.png`
- `04_results_findings.png`
- `05_json_report.png`

## 📞 Need Help?

Jika ada masalah saat recording:
1. Test ulang scanner dulu: pastikan berjalan smooth
2. Check koneksi internet: pastikan stabil
3. Check audio: record test 30 detik
4. Check video quality: 1080p, smooth frame rate

**Good luck dengan recording, Mas L! 🎥🚀**

---
*Generated by Ultimate Security Hunter Development Team*
*Last Updated: October 29, 2026*
